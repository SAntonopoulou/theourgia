# Theourgia — Agent Developer Onboarding

> **You are about to implement the Theourgia design system as a real, running product.**
> This document exists because the most common failure mode is *literal translation* —
> copying a mockup pixel-for-pixel, hard-coding its sample data, and shipping a beautiful
> page that can't actually do anything. Your job is the opposite: read each mockup as a
> **specification of intent**, figure out what is structure vs. content vs. behavior, and
> wire it to real data and real state.
>
> Read this whole file before writing code. Then keep it open.

---

## 0 · How to read this document

There are **50 design surfaces** (`*.dc.html`) plus a shared nav component and a portable
token layer. This onboarding is in six parts:

1. **Foundations** (this part) — the product, the mental model, the reuse framework, tokens,
   typography, icons, the component contract, the app shell, the inferred data model, and the
   cross-cutting rules (a11y, i18n, print).
2–5. **Surface catalog** — every surface, one entry each, with a fixed structure (purpose →
   reusable pieces → dynamic/feed data → static chrome → state & interactions → backend notes
   → gotchas).
6. **Appendices** — domain glossary, a master data-source index, and the QA checklists.

**The mockups are the source of truth for *look*. This document is the source of truth for
*meaning*.** Where they ever disagree, the intent described here wins — tell the maintainer
(Sophia) and we'll reconcile.

> **Companion file:** **`agent_data_and_components.md`** holds the concrete build contracts —
> TypeScript models for every entity, a REST API sketch, the shared-component inventory with prop
> signatures, and the computed-engine function signatures. This file = *meaning*; that file =
> *shapes to build against*. Read this one first, then keep both open.

### What the mockups are, technically

Each `*.dc.html` is a self-contained "Design Component": an HTML file with an inline
`<helmet>` token block, a markup template, and a small logic class. They were authored for
**fidelity and explanation**, not as a deployable frontend. Specifically:

- **All styling is inline** (`style="…"` with `var(--token)` references). That was a constraint
  of the authoring tool so designs paint instantly. **In production you will NOT inline styles** —
  you'll lift the tokens into `tokens.css` (already extracted for you, see §4) and use
  Tailwind/CSS-modules/whatever your stack prefers. The inline values are there so you can read
  the exact intended spacing/color/size at a glance.
- **The logic classes use React-ish `setState`.** Treat them as *interaction sketches*, not
  architecture. They show what's meant to be clickable and what changes when you click — not how
  to structure your real state management.
- **Sample data is illustrative.** Every name, date, gematria value, member, ritual, and price in
  these files is placeholder. Some of it is *computed correctly* (see the "ACCURATE" callouts
  below) and some is just typed in. Never ship the sample data.

---

## 1 · What Theourgia is (the 60-second version)

A **magickal journal CMS and practitioner's toolkit**. Open source (AGPL-3.0), **self-hostable**,
**federated**. It is professional infrastructure for working magicians across many traditions
(Thelema, chaos magic, Greek theurgia, witchcraft, Hermeticism, ceremonial, folk). The bar is
**Notion / Obsidian / Linear**, applied to ritual practice. It is **not** a "spiritual app."

Implications that touch almost every surface:

- **Self-hosted + federated.** There is no single central server. A "vault" is one practitioner's
  instance; "hubs" are networks; instances **federate** (ActivityPub-style peer relationships).
  Health, Federation, and SSO surfaces are admin tools for *running your own node*.
- **Data sovereignty & encryption are first-class.** Content can be **end-to-end encrypted at
  rest** ("Sealed"), per content type. Several surfaces surface key/signature/verification state.
  Never design these as cosmetic badges — they reflect real cryptographic state.
- **Multi-tradition, tradition-neutral by default.** The base theme must feel at home to a
  Thelemite, a Hellenist, and a chaos magician alike. Tradition flavor comes from the user's
  *content* and from optional *theme skins* (`base` / `hellenic` / `thelemic`), never from
  hard-coded chrome.
- **Multilingual is core.** Latin, polytonic Greek, pointed Hebrew, Arabic, Devanagari, Coptic —
  with correct fonts, RTL where needed, and mixed-script paragraphs that look right.
- **Print matters.** Practitioners print ritual sheets, talismans, sigils, and whole books.

---

## 2 · The mental model: structure vs. content vs. behavior

For **every** element you implement, sort it into one of four buckets. This is the single most
important habit this document is trying to install.

| Bucket | Definition | In the mockups it looks like… | What you do with it |
|---|---|---|---|
| **① Chrome / structure** | Layout, navigation, section scaffolding, labels that never change | The sidebar, headers, the "ROSTER" / "BY DEGREE" section labels, column headers, empty-state frames | Build as **static components**. Reuse aggressively. |
| **② Content / feed data** | Anything that represents a user's or network's actual records | Entry titles, entity names, members, rituals, prices, gematria results, ritual scripts, attestations | **Fetch from the API.** The sample values are throwaway. Design the loading / empty / error states (the mockups mostly show the happy "lots of data" state — you must add the others). |
| **③ Derived / computed** | Values calculated from other data or the clock | Planetary hour, lunar phase, gematria totals, geomancy figures, magic-square constants, "renews in N days", timezone-converted ritual times | **Compute on the correct side** (see each surface). Some are pure client math; some need server truth (encryption, signatures, federation reachability). Do NOT store these as static strings. |
| **④ State / behavior** | What changes in response to interaction | Theme/mode toggles, tab switches, filter chips, RSVP, visibility selector, sandbox discard, form inputs | Implement as **real state** with real persistence where it matters (theme prefs, draft content) and real side-effects where it matters (RSVP writes to the hub). |

> **Litmus test before you hard-code any string:** *"If a different practitioner logged in, or it
> were a different day, would this text change?"* If yes, it's ② or ③ — wire it up. If no, it's ①.

A worked example, the **Vault — Today** header widget showing "☿ Hour of Mercury · ☽ Waxing
Gibbous":

- "Hour of" / "·" — ① chrome.
- ☿ Mercury, ☽ Waxing Gibbous — ③ **derived**: computed from the current timestamp + the user's
  latitude/longitude (planetary hours depend on local sunrise/sunset). This must recompute on a
  timer, not render once. The mockup's value is whatever time it was authored.
- The little glyphs — ① from the icon set, but *which* glyph is ③ (depends on the computed body).

---

## 3 · The reuse framework — what is a component, what is a page, what is a feed

The mockups were authored as **one file per surface** with everything inline, for editing
convenience. **Do not mirror that file structure in production.** Instead, decompose along these
lines. Below, "lift" means "extract into a shared, reusable implementation."

### 3.1 Lift these into shared components (used on many surfaces)

These recur across most surfaces — build them **once**, theme them with tokens, and import them
everywhere. (The mockups duplicate them inline; that duplication is an artifact, not a directive.)

- **`AppShell`** — the 248px sidebar + topbar + content/rail grid. The sidebar is already its own
  file: `VaultNav.dc.html` (see §8). Every admin surface uses it with one `active` prop.
- **Theme/Mode controls** — the `Base / Hel / Thel` segmented control + dark/light toggle in every
  admin header. One component; reads/writes the global theme store (§5).
- **The overlay/dialog family** — ConfirmDialog (destructive/constructive/neutral), AlertDialog,
  PromptDialog, Toast (info/success/warning/error), Banner, Drawer, Command Palette, Quick-Capture.
  **These are mandatory and replace ALL native `alert`/`confirm`/`prompt` (hard rule).** The
  `Theourgia Overlays.dc.html` surface is the spec/gallery for them. See §7.
- **Primitives** — Button (primary/secondary/ghost/danger), Switch, SegmentedControl, Chip/Filter
  pill, Field (label+input+error), Card, Badge, Stat tile, ProgressBar, EmptyState, Avatar/identity
  medallion, status Dot. `Theourgia Foundations.dc.html` is the visual spec for these.
- **Icon** — one component over the SVG sprite (§6).
- **Glyph helpers** — planetary/elemental/zodiac glyphs and the celestial widgets (planetary hour,
  lunar phase) appear on Today, Synchronicities, Workshop, Ritual Feed, Scheduler. Lift the
  *computation* (§10.7) into a shared util and the *display* into a small component.
- **VisibilitySelector** — the Personal/Viewer/Network/Public/Sealed control. Spec'd in
  `Theourgia Interaction Patterns.dc.html`. It appears on *every content composer*; build once.
- **Public site chrome** — the lighter public header/footer used by Landing, Blog, Essay,
  Newsletter, Profile, Hub, Book, Docs, Style Guide. One public layout, themeable.
- **Print sheet frame** — the fixed-size parchment surface + `@media print` rules shared by the
  three print surfaces. One print layout primitive.

### 3.2 These are genuine standalone pages/routes

Each surface in Parts 2–5 is a route. Many share the AppShell; their *content region* is the
unique part.

### 3.3 These are feeds / collections (design the list states!)

Anywhere the mockup shows a list of cards or rows, that's a **collection backed by a query**. The
mockup shows it full. **You must additionally implement:** loading skeletons, empty state (with the
humane voice — see §11), error state, pagination/infinite-scroll, and the filter/sort wiring that
the chips imply. The chips in the mockups are real filter controls, not decoration.

Collections in this product (non-exhaustive): journal entries, entities, library items,
synchronicities, divination sessions, saved analytics studies, templates, bundles, agents, hub
members, rituals, attestations, blog posts, newsletter issues, scheduled releases, federation
peers, connected networks, private viewers, invoices.

### 3.4 The "do not over-component" caution

Don't atomize to death. A section that appears on exactly one surface (e.g. the geomancy shield)
stays local to that surface. Lift only what genuinely recurs (§3.1) or what carries real shared
logic (the celestial computations, the visibility model, the dialogs).

---

## 4 · Tokens & theming (the portable layer)

The design is **fully token-driven**. The portable layer is already extracted for you:

```
tokens/
  theourgia.tokens.css          ~70 CSS custom properties: color, font roles, radii,
                                 spacing, shadow, motion. Defines :root (base+dark) then
                                 override blocks for [data-theme] and [data-mode], plus the
                                 a11y layers [data-contrast="high"] and [data-cvd="safe"].
  tailwind.theourgia.preset.js   maps those vars onto Tailwind theme keys (colors.*, fontFamily.*,
                                 borderRadius.*, etc.) so you can use utility classes that resolve
                                 to the tokens.
  theourgia-icons.svg            the 24-symbol engraving icon sprite (see §6).
  README.md                      token model + font rationale + usage.
```

### How theming works (and how to wire it)

Two independent axes, both set as attributes on a root element (`<html>` is ideal):

- **`data-theme`** ∈ `base` | `hellenic` | `thelemic` — swaps the **display font** and nudges the
  accent/background hues. base→Cardo, hellenic→GFS Didot, thelemic→Cinzel.
- **`data-mode`** ∈ `dark` | `light` — dark **leads** (it's a working mode; many rituals are at
  night). Light is fully supported.

Plus opt-in accessibility layers, composable with any theme/mode:

- **`data-contrast="high"`** — collapses soft inks to full ink, hardens borders, solidifies tints.
- **`data-cvd="safe"`** — a blue/teal/amber/vermilion semantic + category palette that survives
  deuteranopia & protanopia. **Always pair color with an icon or shape — color is never the only
  cue.**
- `prefers-reduced-motion` is honored in the token file (kills transition durations).

```html
<html data-theme="hellenic" data-mode="dark" data-contrast="high" data-cvd="safe">
```

**Production wiring:**

1. Put `tokens/theourgia.tokens.css` in your global styles (or adopt the Tailwind preset).
2. Persist the user's theme/mode/a11y prefs (server-side on their account **and** mirrored to
   `localStorage` for first-paint, to avoid a flash). The Settings surface is the UI for these.
3. The per-surface theme switcher in the mockups is a **demo affordance** so you can preview skins.
   In production there's one global control (in Settings / user menu); individual pages don't each
   need their own switcher. Keep it if you want quick per-page preview in admin, but it must write
   to the same global store.
4. **Never introduce a raw hex value in a component.** If you need a color that isn't a token,
   add a token. The whole system's themeability depends on this discipline (it's a locked decision).

### Color semantics you must preserve

- **One accent, three intensities.** Gold (`--accent`) is the only bright color: solid for actions,
  `--accent-soft` for tints, a hairline (`--line-2`) for accents. Don't introduce competing brights.
- **Category hues** (divination / synchronicity / working, and elemental water/earth/fire/air)
  **label**, they don't decorate. Keep them muted and always paired with a glyph.
- **Oxblood/danger** = sacred/sealed/destructive markers. **Success/good** = teal-green.
- The parchment palette is reserved for **print** and a few light-mode reading surfaces.

---

## 5 · Typography & multi-script (the heart of the design)

Typography is the most important layer. Get this right before anything else.

**Font roles (all tokens — themeable):**

| Role | Token | Default face | Used for |
|---|---|---|---|
| Display | `--font-display` | Cardo / GFS Didot / Cinzel (per theme) | Titles, wordmark, hero |
| Serif / text | `--font-serif` | **Cardo** | Body prose, reading, most content |
| UI | `--font-ui` | **Inria Sans** | Labels, nav, buttons, captions, meta |
| Mono | `--font-mono` | **JetBrains Mono** | Gematria values, sigil params, code, degrees |

**Per-script faces** (load and apply by detected script — this is ② behavior, not cosmetic):

| Script | Face |
|---|---|
| Latin | Cardo |
| Polytonic Greek | Cardo (base) / GFS Didot (hellenic display) |
| Hebrew (with niqud) | **Frank Ruhl Libre** |
| Arabic | **Noto Naskh Arabic** |
| Devanagari | **Noto Serif Devanagari** |
| Coptic | **Noto Sans Coptic** |
| Symbols/glyphs | Noto Sans Symbols (fallback for planetary/astro glyphs) |

**Rules that must survive implementation:**

- **Mixed-script paragraphs must look right.** When Greek or Hebrew appears inline in English, the
  correct face is applied to just that run (via lang spans / Unicode-range `@font-face`, not manual
  spans everywhere). Hebrew & Arabic runs set **RTL** correctly even inside an LTR paragraph.
- **Reading vs. ritual quotation are typographically distinct** (size, face, leading) — see Essay
  and Editor.
- Drop caps, small caps, true italics, oldstyle figures are used and intended. Don't lose them.
- **Minimum sizes:** body text never below ~15px on screen; print ≥ 12pt; ritual-mode text is huge
  by design (hands-free at arm's length).
- `text-wrap: pretty` / `balance` are used on headings and reading measures — keep them.

See `tokens/README.md` for the full font rationale (deliverable #2).

---

## 6 · Iconography

- **Custom engraving set only.** No Lucide/Heroicons (locked decision + brief). Uniform ~1.4 stroke,
  `currentColor`, simple geometry, legible at 16px.
- Sprite is shipped: `tokens/theourgia-icons.svg` — 24 `<symbol>`s (journal, library, scroll,
  feather, entity, shield, divination, sigil, pentacle, star, flask, compass, ritual, trance, eye,
  candle, hand, bell, moon, sun, calendar, lock, key). Use `<svg><use href="#theo-…"/></svg>`.
- **Subject glyphs** (planetary, zodiac, elements, decans, lunar phases) are a *larger* set the
  product needs. The mockups use Unicode astro glyphs (☿ ☉ ☽ ♄ ♃ ♂ …) via the symbol font as a
  stand-in. For production, commission/extend the engraving set to cover these subjects and serve
  them through the same sprite + `Icon` component. Track this as a real asset-production task.
- Color comes from `currentColor` → set it with the text color token. Icons inherit theme for free.
- Provide the sprite **and** a thin `Icon`/`Glyph` component (the brief asks for "SVG sprite + React
  components"). Tiny sizes (≤16px) bump stroke to ~2 for legibility.

---

## 7 · The component contract — overlays, forms, feedback (HARD RULES)

> **No native browser dialogs. Ever.** `alert()`, `confirm()`, `prompt()` are prohibited (enforced
> by ESLint in the real repo). Every confirmation, alert, prompt, error, and notification uses the
> themed component family. This is non-negotiable and it's why the family exists.

`Theourgia Overlays.dc.html` is the gallery/spec. Build these as the foundation of your UI kit:

- **ConfirmDialog** — three intents: **destructive** (oxblood, "Delete / Revoke / Archive"),
  **constructive** (gold, "Publish / Admit / Release now"), **neutral**. Focus-trapped,
  ESC-dismissible, returns a promise. Used by: Identities (archive), SSO (revoke), Scheduler
  (release-now/cancel), Memorial, Bundle Install, Membership (decline), Wellbeing, etc.
- **AlertDialog** — single-action acknowledgement for **irrevocable** consequences ("this
  permanently deletes…"). Stronger than Confirm; no silent dismissal of the consequence.
- **PromptDialog** — themed text input request (replaces `prompt()`).
- **Toast** — info / success / warning / error; transient; never used for anything requiring a
  decision. Cost-cap warnings, "saved", "copied", etc.
- **Banner** — persistent contextual message in-page (e.g. "You are previewing as Observer",
  "This vault is in memoriam", sandbox notice).
- **Drawer** — slide-in side panel (detail/edit rails, filters on narrow screens).
- **Command Palette (Cmd/Ctrl-K)** — app-wide navigation + actions. Real keyboard handling, fuzzy
  search, recent items.
- **Quick-Capture** — global shortcut → small modal for fast synchronicity/dream/sensation logging
  from anywhere. Writes a real entry with type + visibility. (The sidebar's "Quick capture ⌘K"
  button opens this.)

Every one: themed (incl. high-contrast), focus-trapped, ESC-dismissible, keyboard-navigable,
screen-reader-correct (roles, `aria-modal`, labelled). Reduced-motion respected. **Build these
early** — dozens of surfaces depend on them and will otherwise tempt someone into a native dialog.

---

## 8 · The app shell — `VaultNav.dc.html`

The 248px left sidebar is already its own component. It takes one prop, `active` (the current
nav key), and renders the sectioned nav with engraving icons:

- **Quick capture** button (opens the Quick-Capture overlay, ⌘K).
- **Practice**: Today, Journal, Synchronicities.
- **Reference**: Entities, Library, Calendar.
- **Workbench**: Divination, Sigil Studio, … (workshop tools).
- **Network**: Ritual Feed, Hubs (Membership/Hub).
- Footer: Settings, identity switcher.

Implementation notes:

- Nav items, their order, and which sections appear are partly **②** — they depend on enabled
  features/plugins and the user's role (an observer sees fewer; agents/federation hide if disabled).
  Don't hard-code the full list as immutable; drive it from a nav config gated by
  capabilities/feature-flags.
- The **active identity** and **acting-as** state live here (the identity switcher). See Identities.
- **App-shell scroll convention (critical, learned the hard way):** the shell is a CSS grid with
  `grid-template-rows: minmax(0,1fr)` and **every** internal scroller (`main`, side rails) carries
  `min-height:0` alongside `overflow-y:auto`. Without both, the grid row auto-sizes to content and
  the root's `overflow:hidden` *clips* instead of scrolling — it looks fine only until content
  exceeds the viewport. Bake this into your AppShell layout primitive once.
- Document/specimen pages (Foundations, Profile, Blog, Essay, Newsletter, Docs, Hub, Book, Book
  Preview, Style Guide, the print sheets) do **not** use the app shell — they're public/print and
  **page-scroll** (single `min-height:100vh` wrapper, no inner overflow).

---

## 9 · Responsive, density, motion

The mockups are authored at desktop width but the product ships **fully responsive — mobile, tablet,
small- and large-desktop**. This is implemented, not aspirational: every app-shell surface carries a
shared responsive block and an off-canvas nav drawer. Re-create the system exactly; don't reinvent it
per surface.

### 9.1 · Breakpoints (the four bands)

| Band | Range | Shell behavior |
|---|---|---|
| **Large desktop** | ≥ 1367px | Full layout. Sidebar 248px + content + right rail(s) side-by-side. |
| **Small desktop** | 1025–1366px | Sidebar narrows to **224px** (`--shell-nav-w`); rails begin to wrap via the existing `flex-wrap`/`auto-fit`. |
| **Tablet** | 641–1024px | **Sidebar becomes an off-canvas drawer**; content goes full-width single-column; hamburger appears in the topbar. |
| **Phone** | ≤ 640px | Drawer nav; topbar padding + gaps tighten; secondary topbar controls (theme segmented, search label) condense or hide; content is a single column. |

Token breakpoints: `@media (max-width:1280px)` shrinks `--shell-nav-w`; `@media (max-width:1024px)`
flips to the drawer; `@media (max-width:640px)` is the phone polish. (1024/640 are the load-bearing
two; 1280 is a refinement.)

### 9.2 · The responsive contract: tokens + inline base, overrides in `<helmet>`

Inline styles can't hold media queries — but the project styles **everything** inline for
first-paint. The reconciliation, which is the **one sanctioned use of `<helmet><style>` beyond theme
tokens**: the **desktop/base layout stays inline** (so it paints immediately and correctly on
desktop), and a small shared `@media` block in `<helmet>` **overrides** it at smaller widths via a
handful of namespaced `om-*` class hooks. Responsive sizing that's just a number (column width,
padding) rides **layout tokens** (`--shell-nav-w`, `--shell-pad`) redefined per breakpoint; structural
changes (drawer) use the `om-*` hooks. Never restyle elements inline-vs-class twice for the two states
beyond what the hooks require.

### 9.3 · The off-canvas nav drawer (shared, framework-agnostic)

Below 1024 the sidebar (`VaultNav`, class `om-aside`) becomes a fixed off-canvas drawer. The
mechanism is deliberately **not** React state, so it drops into any surface with zero logic-class
edits:

- **`om-shell`** on the root grid div. The drawer's open/closed state is the attribute
  `data-nav-open="true|false"` on this element — **managed by a small delegated script, not React**
  (the attribute isn't in any template, so React never reconciles or clobbers it).
- **`om-aside`** on the sidebar. `@media (max-width:1024px)` makes it `position:fixed; width:284px;
  z-index:60; transform:translateX(-100%)`; `.om-shell[data-nav-open="true"] .om-aside{ transform:none }`
  slides it in.
- **`om-menu`** — the hamburger `<button>`, first child of the topbar (`om-topbar`). `display:none`
  by default; `inline-flex` below 1024.
- **`om-scrim`** — a child of `om-shell`; the dim backdrop. `display:none` by default; below 1024 it
  covers the viewport at `z-index:55` and fades in with the drawer.
- **Delegated controller** (one `<script>` in `<helmet>`, identical on every surface, guarded by
  `window.__omNavWired`): a document-level `click` listener toggles `data-nav-open` when an
  `.om-menu` is clicked and closes on `.om-scrim`; a `keydown` listener closes on **Escape**. Event
  delegation means it works for DOM that streams in later — no init-timing fuss.

Because it's delegated + attribute-driven, the same block is copy-paste identical across all ~30
app-shell surfaces. (`Theourgia Vault - Today.dc.html` inlines its own sidebar rather than importing
VaultNav, so it expresses the *same* contract through React state — `navOpen` + `toggleNav`/`closeNav`
+ an ESC handler. Either is fine; the CSS contract is the same.)

**Accessibility:** the hamburger is a real `<button>` with `aria-label` + `aria-expanded` (kept in
sync); ESC closes; the scrim is click-to-close; nav links get `min-height:44px` in drawer mode for
touch. Reduced-motion drops the slide transition. Production should additionally **focus-trap** the
open drawer and return focus to the hamburger on close (the mockups wire the rest).

### 9.4 · Per-archetype recipe

- **App shell (Today, Journal, workbench, admin, network):** the drawer block above + `om-topbar` on
  the topbar. Content already reflows via `flex-wrap`/`auto-fit` — verify rails wrap cleanly.
- **3-pane workbenches (Sigil, Talisman, Circle, Editor, Divination):** the drawer handles nav, but
  the **3 panes must stack** below ~900px (method → canvas → properties become vertical). Give the
  pane grid a hook and stack it in the media block; make the canvas the priority pane.
- **Page-scroll public/document (Landing, Blog, Essay, Newsletter, Docs, Profile, Hub, Book, Book
  Preview, Foundations, Style Guide, SSO):** no app shell. The gaps are (a) the **public top-nav**
  (horizontal links) → collapse to a menu/disclosure below ~720px; (b) **multi-column content grids**
  (Docs 3-col, Foundations specimens) → stack; (c) **hero type** → scale down with `clamp()`. Content
  already flows single-column; mind padding (`clamp(16px, 5vw, 48px)`).
- **Specialized modes (Trance, Ritual):** already full-bleed and centered; just ensure the big type
  uses `clamp()` and stays ≥ the a11y floor, and step controls are ≥44px touch targets.
- **Print sheets:** fixed page size for print is correct; for *screen preview* on a phone, let the
  parchment scale to viewport width (`max-width:100%`) so it doesn't overflow.

### 9.5 · Density & motion (unchanged by viewport)

- **Density is editorial, not cramped.** Respect the whitespace — it's load-bearing for the
  "serious antiquarian" feel. Don't compress to fit more in; on small screens, drop or stack content
  rather than shrinking it below comfortable/legible sizes.
- **Type floors hold everywhere:** body never below ~15px on phone; touch targets ≥44px.
- **Motion is a whisper:** 150–250ms, no bounce, no parallax, no spinner-as-feature. Honor
  reduced-motion. The drawer slide is the only new motion — keep it to ~280ms ease, no overshoot.

### 9.6 · QA per surface (add to the §E checklist)

- [ ] Verify at **375 / 768 / 1024 / 1440**. No horizontal scroll at any width (200% zoom too).
- [ ] Below 1024: drawer opens from the hamburger, scrim dims, ESC + scrim-click close, focus visible.
- [ ] Nav links + buttons ≥44px touch in drawer mode.
- [ ] 3-pane/multi-column content stacks rather than overflowing.
- [ ] Public nav collapses; hero type scales; nothing clips off the left edge.

---

## 10 · Inferred data model (so you know what every feed is *of*)

The mockups imply a backend. This is the model to build against; confirm specifics with the
architecture docs, but the **shapes** below are what the surfaces assume.

### 10.1 Vault, identities, visibility
- **Vault** — one practitioner's instance/account (self-hosted or hosted tier).
- **Identity** — an author persona. A vault has **many**. Each has avatar, display name, bio, and
  its **own signing keypair**. Entries/posts/publications are authored *as* a chosen identity;
  defaults are configurable per content-kind (Settings/Identities). One identity may be an
  unlinkable pseudonym (the chaos-magician persona) — deliberately **unsigned / no lineage** to
  preserve unlinkability. Identities can be **archived** (not deleted).
- **Visibility** (on every content item): `Personal` (owner only) · `Viewer` (named private
  viewers) · `Network` (hubs you've joined) · `Public` (open web, signed) · `Sealed` (E2E encrypted
  at rest). This is a real access-control + crypto property, surfaced by the VisibilitySelector.

### 10.2 Content types
- **Journal entry** — the core record. Has type (working, dream, divination, synchronicity, note…),
  identity, visibility, timestamps (with planetary hour/lunar phase captured at write time),
  body (Tiptap doc with custom blocks), links to entities/workings.
- **Synchronicity** — lightweight entry with a "charge", auto time/place/planetary-hour, optional
  linked working/entity.
- **Divination session** — tarot/I Ching/geomancy/runes/scrying; stores the cast + interpretation.
- **Blog post** — separate from journal; type (article/note/quote/link/photo/video), excerpt,
  featured image, tags, publish/schedule state, identity.
- **Publication / Book** — long-form, print-targeted; chapters, footnotes, glossary, index, cover,
  trim size, format/price (Stripe).
- **Newsletter issue** — "The Theurgist's Almanac"; subject, preview text, body, audience, send-as
  identity, schedule.
- **Template** — reusable entry structure (block skeleton) with category + usage count.

### 10.3 Entities & alias graph
- **Entity** — god/spirit/angel/demon/saint/ancestor; class, tradition, planetary/elemental
  correspondences, epithets, library refs.
- **Alias graph** — typed edges between entities: `same-as` / `aspect-of` / `syncretic-with` /
  `epithet-of`. Read-mostly graph; "Add alias" relates two with a type.
- **Unified view** — a saved union of entity_ids (e.g. `Hekate-all` = three entities). The editor's
  `<entity-ref>` block can target a *specific* entity or a *unified view*; the choice is stored.

### 10.4 Library
- **Library item** — primary source / text / deck; category, language(s), spine-coded shelving,
  citations used by entities and quotes.

### 10.5 Network / hub / federation
- **Hub** — a network/order (e.g. "Ordo Theurgica"). Public face + private membership. Has
  officers, degrees/roles, rites, writings, lineage, a verified key, a ritual schedule.
- **Membership** — a vault's belonging to a hub, *as a chosen identity*, with a degree/role and
  standing (good / dues-owing / suspended). Petitions to join are pending memberships.
- **Role & permission** — granular permission matrix (30+ perms grouped by domain); roles are
  bundles; "preview as role" simulates a role's permissions; permission templates (coven/lodge/…).
- **Ritual (group)** — scheduled shared working; time is stored canonically and **rendered in each
  viewer's timezone + their local planetary hour**; RSVP (going/maybe/can't); post-ritual
  collective log merges participant notes; iCal feed.
- **Federation peer** — another instance; federation mode (open/invite/off); trust badge; software;
  shared scope; reachability/latency (live health); peers can be blocked.
- **SSO** — "Sign in with Theourgia" to a hub; consent screen picks which identity to present and
  shows live scopes (will-see / never-shared); connected-networks history; per-hub revoke; hubs may
  require approval (access-request queue).
- **Lineage attestation** — a signed claim (initiation/degree/teacher/membership). States:
  self-declared-unsigned / counter-signed-by-authority / revoked. "Verify signature" fetches the
  authority's public key and validates **in-browser**.

### 10.6 Encryption, inheritance, agents, bundles
- **Sealed content** — E2E encrypted under the user's key; not even a stolen DB (or the server, or
  the user without the key) can read it. Settings toggles encryption per content type with strong
  warnings.
- **Digital inheritance** — designate an executor via a key-share mechanism; a check-in mechanic
  ("if I don't log in for N months, notify X"); a trigger flips the vault to **memorial mode**
  (in-memoriam framing, only public content, no active interactions, preserved permanently);
  entries can be marked for posthumous release.
- **AI agents** (opt-in) — per-purpose agents (divination companion, scrying partner, …) with a
  capability **allowlist**, a memory directory, model selection, cost caps, token-usage dashboard,
  and a human-readable activity log. BYO keys ("your keys never leave your instance").
- **MBF — Magickal Bundle Format** — a shareable package of a magickal system (pantheon/tradition/
  ritual/deck/sigil library). Has a manifest, signature/verification tier (Official/Community/
  Unverified), license, provenance chain, install count. Install flow: preview → license → mode
  (sandbox-first **recommended**, or direct) → select items → resolve alias conflicts → confirm.
  **Sandbox** runs imported content in isolation (no network, can't touch the real vault) until
  promoted; closed-tradition bundles carry a respect-source notice and block public-share.

### 10.7 Computed / temporal (compute these — never store as strings)
- **Planetary hour** — from local timestamp + lat/long (needs sunrise/sunset). Recompute on a timer.
- **Lunar phase / illumination** — from timestamp.
- **Transits of note** — from an ephemeris.
- **Multi-calendar dates** — every date can reveal alternate calendar systems on hover/tap
  (calendar-layer toggling). The display value is derived from the canonical timestamp.
- **Gematria** — Latin/Greek/Hebrew letter sums (full / ordinal / reduced). Pure client math; the
  Workshop calculator is correct — lift its logic into a shared util and reuse in the editor's
  `/gematria` block.
- **Geomancy** — 4 Mothers cast → Daughters/Nieces/Witnesses/Judge derived by XOR rules. The Oracle
  implements the 16 figures and derivation correctly. **Lift this; don't re-derive from scratch.**
- **I Ching** — coin cast → 6 lines → hexagram via the **King Wen** table; changing lines → relating
  hexagram. The Oracle's table is **verified correct** — reuse it verbatim.
- **Magic squares (kamea)** & planetary constants — Talisman/Sigil studio compute the square and the
  magic constant; sigils are traced over the kamea. Correct in the mockups; lift the math.
- **Transliteration** — Latin→Greek/Hebrew, digraph-aware, Greek final-sigma, Hebrew RTL. The
  Transliterate surface has a working mapping; reuse for the editor's romanization helper.

> **"ACCURATE — reuse the logic" surfaces:** Oracle (I Ching table + geomancy derivation), Workshop
> (gematria, planetary hour, barbarous names), Talisman & Sigil Studio (kamea + magic constant +
> sigil tracing), Circle (tradition attributions), Transliterate (script mapping). Treat their logic
> classes as reference implementations to port, not as throwaway sketches.

---

## 11 · Voice, a11y, i18n, print — cross-cutting, applies to every surface

**Voice (for any UI copy you write or generate):** confident, quiet, exact. Direct — never "manifest
your dreams!". Latin/Greek sparingly as ornament (`Solve et coagula`, `Γνῶθι σαυτόν`). **Error copy
is humane and never blames the user** ("That working failed to save. Your text is kept — try again
when ready."). Empty states use this voice, not cheery filler. `Theourgia Style Guide.dc.html` is
the canonical reference; read it before writing copy.

**Accessibility (WCAG 2.2 AA — non-negotiable, enforced):**
- Contrast ≥ 4.5:1 body / 3:1 large, in **all** themes/modes. The `high` and `cvd` layers exist for
  this — wire them to Settings and test with them on.
- Full keyboard path; visible focus ring always (2px accent, 2px offset — already in tokens); never
  remove outlines. Dialogs focus-trap + ESC; menus arrow-navigable.
- Screen-reader semantics: landmark roles, labelled controls, `aria-pressed`/`aria-current` on the
  toggles & nav (the mockups already set many of these — preserve them).
- Color is **never** the only cue — pair with icon/shape/text (critical for the category hues,
  standing dots, status, visibility levels).
- 200% zoom with no horizontal scroll; reduced-motion alternative for every animation; form errors
  announced.

**Internationalization / RTL:**
- All UI copy through i18n; don't bake English into components.
- Hebrew & Arabic content sets `dir="rtl"`; the layout must mirror correctly (not just the text).
  Mixed-script paragraphs (§5) must render each run in its correct face/direction.
- Dates/numbers localized; calendar-layer toggle reveals alternate systems.

**Print (real requirement, not a nicety):**
- The three print surfaces (Ritual Sheet, Talisman & Sigil, Book Preview) use a **fixed-size
  parchment surface + `@media print`**. Implement true print CSS (page size, margins, crop/bleed
  marks where shown, no app chrome). Practitioners print these for real use.

---

*Part 1 ends here. Parts 2–5 catalog every surface; Part 6 is the appendices (glossary, data-source
index, QA checklists). Each surface entry uses this fixed structure:*

> **Purpose** · **Route & shell** · **① Reusable pieces** · **② Dynamic / feed data** ·
> **③ Derived** · **④ State & interactions** · **Backend notes** · **Gotchas**

---

# Part 2 · Surface catalog — System & Public

These set the visual language (system surfaces) and are the unauthenticated, indexable web
(public surfaces). Public surfaces **page-scroll** and use the lighter public chrome (§3.1),
**not** the app shell. They must be fast, SEO-correct, and server-renderable.

## SYSTEM / SPEC SURFACES (build your UI kit from these — they are not routes)

### `Theourgia Foundations.dc.html` — the component & token specimen
- **Purpose.** The living spec for the design system: wordmark lockups, type roles + display scale
  + per-script faces (Greek/Hebrew/Arabic/Devanagari/Coptic/gematria), live color-token swatches
  (surfaces, semantic, the 6 category accents), radii/spacing/elevation, the 24-icon engraving set,
  and the core components (buttons, switch, segmented control, chips, field).
- **How to use it.** This is your **acceptance reference** for the primitives in §3.1. Implement each
  specimen as a real component; this page becomes your Storybook equivalent. It re-skins live across
  theme×mode — your components must do the same with zero code change (token-only).
- **② / ③.** None — everything here is static spec. The only "data" is the token values, which come
  from `tokens.css`.
- **Gotcha.** Don't ship this as a user route; it's internal. Keep it (or a Storybook) as the place
  the icon/glyph subject-set (§6) gets expanded and signed off.

### `Theourgia Style Guide.dc.html` — voice, do/don't, a11y (document)
- **Purpose.** Canonical **copy & conduct** reference: voice DO/DON'T columns, ornament-&-restraint
  rule pairs, color/motion/density principles, the WCAG 2.2 AA checklist, and "the lines we never
  cross" (no native dialogs, no emoji decoration, no kitsch, no filler).
- **How to use it.** Read before writing any UI copy, empty state, or error. Encode the a11y
  checklist into your CI/lint where possible. Static document; no data.

### `Theourgia Overlays.dc.html` — the dialog/feedback family (spec → build first)
- **Purpose.** Gallery + spec for the mandatory overlay family (§7): ConfirmDialog (3 intents),
  AlertDialog, PromptDialog, Toast (4 kinds), Banner, Drawer, Command Palette, Quick-Capture.
- **① Reusable.** This is **the** highest-leverage build in the whole project — dozens of surfaces
  call these. Build them as a robust, headless-then-styled set early.
- **④ State.** Each is an interaction primitive: promise-returning dialogs, a toast queue/store, a
  global command-palette index, the global quick-capture (writes a real entry).
- **Backend.** Quick-Capture writes an entry (type + visibility + auto planetary-hour). Command
  palette indexes routes + recent records (a search query). Toasts are client-only.
- **Gotcha.** These must be **theme/high-contrast aware, focus-trapped, ESC-dismissible, SR-correct,
  reduced-motion-safe** from day one. If any native `alert/confirm/prompt` survives, the build fails
  the hard rule.

---

## PUBLIC SURFACES (unauthenticated web · page-scroll · public chrome)

### `Theourgia Landing.dc.html` — marketing / manifesto
- **Purpose.** theourgia.com home: the scientific-illuminism pitch. First impression of the whole
  project's seriousness.
- **Route & shell.** `/` (or marketing site). Public chrome, page-scroll.
- **① Reusable.** Public header/footer, Button, type system, wordmark.
- **② Dynamic.** Mostly **static marketing copy** — but treat the hero stat(s), any "latest from the
  blog" teaser, and download/version/install links as ② (pull current release/version, latest post).
- **③ Derived.** None of note.
- **④ State.** Theme/mode switcher (here it's a genuine preview affordance for visitors); newsletter
  email capture (writes to the list — real form, real validation, humane errors).
- **Gotcha.** This is the one surface where the per-page theme switcher is legitimately user-facing
  (let visitors preview skins). Keep marketing claims in CMS/MDX, not hard-coded in components.

### `Theourgia Blog.dc.html` — per-vault public blog homepage
- **Purpose.** A magician's public blog: editorial homepage, featured essay, a typed post stream
  (essay / note / quote / link), subscribe.
- **Route & shell.** `/@identity/blog` (per **identity**, see multi-author note). Public chrome,
  page-scroll.
- **② Feed.** The post stream is a **collection** (paginated query over blog posts, filterable by
  type — the type tabs are real filters). Featured essay = the pinned/most-recent. Each card →
  Essay page. **Multi-author:** when several identities posted to one blog, show which identity
  authored each (and the blog may aggregate identities).
- **③ Derived.** Relative dates (with calendar-layer reveal); reading-time estimate.
- **④ State.** Type filter, subscribe form, load-more.
- **Gotcha.** Posts belong to an **identity**, not "the user" — the same vault's two identities may
  keep separate public faces. Don't collapse them. Design loading/empty/error for the stream.

### `Theourgia Essay.dc.html` — single long-form reading page (RSS-rendered article)
- **Purpose.** The actual reading view behind a blog/essay link: scroll progress bar, editorial
  long-form (eyebrow/title/deck, byline + Signed badge, drop cap, subheads, pull quote, Greek
  epigraph card, gematria aside, footnotes), author card, prev/next, subscribe footer.
- **② Feed.** The article body (Tiptap → rendered HTML), title/deck/byline, footnotes, prev/next
  neighbors, author card (identity), the epigraph/gematria asides (these are **content blocks** in
  the doc, not chrome).
- **③ Derived.** Scroll-progress (client), reading time, the **Signed badge** (verify the author
  identity's signature on the post — real crypto state, §10.5), gematria aside value (compute).
- **④ State.** Scroll progress; footnote popovers; subscribe.
- **Gotcha.** "Signed" is **③ derived from a real signature check**, not a static badge. The custom
  blocks (pull quote, epigraph, gematria aside) must round-trip from the editor — they are the same
  block types defined in `Theourgia Editor.dc.html`. Reading vs. quotation typography is distinct
  (§5) — preserve it.

### `Theourgia Newsletter.dc.html` — newsletter archive (The Theurgist's Almanac)
- **Purpose.** Public archive: hero + subscribe with cadence/reader stats, featured latest issue
  (№ + topic chips → Essay/issue), year-grouped archive list, RSS / view-in-browser footer.
- **② Feed.** Issues are a **collection** grouped by year (№, title, blurb, month). Reader/cadence
  stats are ② (real counts). Featured = latest published issue.
- **③ Derived.** "Timed to the new moon" cadence copy is fine as static framing, but the **next
  send date** if shown is ③ (lunar computation, §10.7).
- **④ State.** Subscribe form.
- **Gotcha.** Pairs with the **Newsletter Composer** (admin) and **Scheduler** — an issue here is the
  published output of that pipeline. Keep the email-address placeholder from being mangled by any
  email-obfuscator (a real bug we hit — render the subscribe input value carefully).

### `Theourgia Docs.dc.html` — documentation site (Astro Starlight-style)
- **Purpose.** Self-hosting docs: 3-column (sticky nav tree + article + "on this page" TOC), header
  with search/version/GitHub, content with syntax-highlighted terminal blocks (copy button),
  NOTE/WARNING/TIP admonitions, config tables, next-steps cards, prev/next pager.
- **② Feed.** Doc content comes from **MDX/markdown files** (the nav tree, article body, TOC, version
  list are all generated from the docs source — this is a static-site-generator surface, likely
  Astro Starlight customized to these tokens). Search indexes the docs.
- **③ Derived.** Active nav item + active TOC anchor (scroll-spy); current version.
- **④ State.** Nav expand/collapse, TOC scroll-spy, copy-to-clipboard, version switcher, search.
- **Gotcha.** Don't hand-author pages — wire the **token theme into Starlight** and let content come
  from markdown. The mockup shows *one* article's worth of chrome; the system generates all of it.
  Cross-links to the Health dashboard.

### `Theourgia Profile.dc.html` — per-identity public profile
- **Purpose.** A visitor's view of one **identity's** public face: identity hero, verified-key card +
  lineage attestations, public writings. Includes an **owner "preview-as" banner** (see yourself as
  Theo / Frater / anonymous). Demonstrates the **unsigned / no-lineage** state for the unlinkable
  chaos pseudonym.
- **Route & shell.** `/@identity`. Public chrome, page-scroll. (Owner sees an extra preview banner.)
- **② Feed.** Identity profile (avatar/name/bio), public writings collection, lineage attestations
  list, hub/order memberships shown publicly.
- **③ Derived.** **Verified-key card** and each attestation's state (self-declared / counter-signed /
  revoked) are **real signature checks** (§10.5). The anonymous persona deliberately shows
  *unsigned + no lineage* — that's an intentional state, not missing data.
- **④ State.** Owner preview-as switcher (Theo / Frater / null=anonymous); "verify signature" runs an
  in-browser key fetch + validate.
- **Gotcha.** **Unlinkability is a feature.** Never leak that two identities share a vault. The
  preview-as is owner-only and must not change what the public actually sees.

### `Theourgia Hub.dc.html` — per-hub public face
- **Purpose.** An order's public homepage (e.g. Ordo Theurgica): hero with unicursal-star watermark +
  Latin motto + stats, about, public rites (open/visitors), order writings, **petition-to-join**
  card, lineage-descent web, officers (→ profiles), verified-hub key.
- **Route & shell.** `/hub/:slug`. Public chrome, page-scroll.
- **② Feed.** Hub profile, public rites (from the ritual schedule, filtered to public), writings,
  officers (→ their identity profiles), lineage descent, stats (member counts).
- **③ Derived.** Verified-hub key (signature check); rite times → viewer's timezone if shown.
- **④ State.** Petition-to-join (writes a pending membership — see Membership admin); subscribe.
- **Gotcha.** This is the **public** half; **Membership** is the **admin** half of the same hub.
  Officers link to **Profile**; lineage links to **Lineage**. The petition flow's other end is the
  "Petitions to read" list on Membership.

### `Theourgia Book.dc.html` — book sales page (Theourgia Press)
- **Purpose.** Sell a book: rendered cover, format selector (hardcover/paperback/digital → live
  price + availability), about, contents, reviews, spec sheet, author card, same-press list,
  "Look inside" sample → Book Preview.
- **② Feed.** Book record (title, blurb, contents, specs), reviews collection, author identity,
  related titles, **price/availability per format from Stripe** (real product/price objects).
- **③ Derived.** Selected-format price/availability (switches live with the selector).
- **④ State.** Format selector, "Look inside" sample sheet (→ Book Preview), add-to-cart/checkout
  (Stripe).
- **Gotcha.** Prices/availability are **② from Stripe**, not typed constants. The cover must match
  what the **Cover designer** (Book Preview) produced — same asset.

### `Theourgia Book Preview.dc.html` — print-quality book preview & cover designer
- **Purpose.** (Bridges public/print/admin.) Interior facing-page spread (drop cap, footnote,
  glossary marker, folios, gutter), cover designer (back·spine·front, barcode, unicursal mark),
  auto index + glossary; trim-size selector, crop/bleed toggles, spread navigation. Fixed-parchment
  **print** surface.
- **② Feed.** Book content (chapters, footnotes, glossary terms, index keys), cover fields.
- **③ Derived.** **Auto-generated index & glossary** (computed from marked terms/keys in content),
  pagination/folios, spine width (from page count + paper), barcode (from ISBN).
- **④ State.** Trim-size selector, crop/bleed mark toggles, spread nav, cover layout edits, "publish".
- **Backend.** Real pagination/typesetting engine for print-grade output (page size, bleed, crop).
- **Gotcha.** This is **admin authoring + print preview**, even though it shares the public Book's
  cover. Index/glossary are **③ generated**, editable before publish — not hand-typed lists.

---

# Part 3 · Surface catalog — Vault admin core & Workbench

All of these use the **app shell** (`VaultNav` + topbar + content/rail, §8) and the app-shell scroll
convention. They are authenticated, per-vault, and act *as the active identity*.

## VAULT ADMIN CORE

### `Theourgia Vault - Today.dc.html` — home / today dashboard
- **Purpose.** The daily landing: multi-calendar today widget, current planetary hour, lunar phase,
  transits of note, recent entries, quick capture.
- **① Reusable.** App shell, celestial widgets (planetary hour / lunar phase — shared), Stat tiles,
  entry-row list, Quick-Capture trigger.
- **② Feed.** Recent entries (collection, most-recent N across types), transits of note (ephemeris).
- **③ Derived (the whole top band).** Planetary hour, lunar phase/illumination, multi-calendar date,
  transits — **all computed from the clock + the user's location**, recomputed on a timer (§10.7).
  The mockup's values are frozen at authoring time; do **not** ship them.
- **④ State.** Quick-capture (type + visibility are interactive → writes a real entry); calendar-layer
  reveal on dates.
- **Gotcha.** This is the surface most often mis-shipped with hard-coded "Hour of Mercury". The
  celestial band is the canonical **③ derived** example from §2. Empty state for a brand-new vault
  (no entries yet) must be designed — humane voice.

### `Theourgia Journal.dc.html` — journal index
- **Purpose.** The entry collection with multiple view modes: chronological / by tag / by entity / by
  tradition / by working. Filters + a facet rail.
- **② Feed.** Entries (the core collection), grouped per the active view. Facet rail counts (tags,
  entities, traditions) are ② aggregations.
- **③ Derived.** Group headers (date buckets, etc.) derive from the view mode.
- **④ State.** View tabs, filter chips, facet selection — **all real query params** that refetch.
- **Gotcha.** The "views" are **server-driven groupings/sorts**, not just client reshuffles of one
  page of data. Build the query layer. Design loading skeletons + empty-per-filter states.

### `Theourgia Entities.dc.html` — entity index
- **Purpose.** Browse gods/spirits/angels/demons/saints/ancestors: class filters, glyph-medallion
  cards, tradition/planet facets.
- **② Feed.** Entities collection; facet counts (class, tradition, planet).
- **③ Derived.** The medallion glyph per entity (from its class/correspondences).
- **④ State.** Class filter, facet selection, search → card → Entity Profile.
- **Gotcha.** Entities participate in the **alias graph** (§10.3) — a card may represent one specific
  entity or stand in for a unified view depending on context. Keep the identity of each card precise.

### `Theourgia Entity Profile.dc.html` — entity detail + alias graph
- **Purpose.** One entity: correspondences, the **alias graph** (node-edge, typed edges:
  same-as/aspect-of/syncretic-with/epithet-of), the **unified-views** panel, library refs. Includes
  the **import-alias prompt** pattern (also used in Bundle Install).
- **② Feed.** Entity record + correspondences, the alias edges (graph), unified views this entity
  belongs to, library citations.
- **③ Derived.** Graph layout positions.
- **④ State.** "Add alias" (dialog: pick related entity + relationship type → writes an edge);
  unified-view editor (drag-select member entities → saves a union); import-alias prompt (on bundle
  import collisions: relate vs. keep distinct, default **distinct**).
- **Gotcha.** The graph is **read-mostly but editable** via typed edges — model the edge types
  exactly (they have meaning). The `<entity-ref>` editor block targets either a specific entity or a
  unified view; that choice is stored on the block (§10.3).

### `Theourgia Library.dc.html` — library catalog
- **Purpose.** Primary sources/texts/decks: spine-coded rows, category filters, language facets.
- **② Feed.** Library items collection; category + language facet counts.
- **③ Derived.** Spine color/shelf code from category.
- **④ State.** Category filter, language facet, search → item (used as citations elsewhere).
- **Gotcha.** Library items are **referenced** by entities and by quote/citation blocks — they're a
  shared catalog, not standalone trivia. Model the citation relationship.

### `Theourgia Settings.dc.html` — settings (appearance, fonts, a11y, encryption)
- **Purpose.** Appearance/theme cards, mode, **font roles**, a11y switches, and **per-content-type
  encryption** with strong warnings.
- **① Reusable.** Switch, SegmentedControl, theme cards, the warning Confirm/Alert dialogs.
- **②/③.** Reads & writes the user's preference record + the vault's encryption config.
- **④ State (consequential).** Theme/mode/font/a11y write to the **global theme store** (§4) and
  persist server-side + localStorage. **Encryption toggles are dangerous** — enabling zero-knowledge
  on a content type triggers a strong AlertDialog (you may lose access if you lose your key); these
  are real crypto state changes, not cosmetic.
- **Gotcha.** This is the real home of the theme/a11y controls that the mockups scatter as per-page
  switchers. Subnav links out to **Account** (memberships/viewers/billing), **Federation**,
  **Wellbeing**. Encryption warnings use the humane-but-serious voice.

### `Theourgia Account.dc.html` — account settings (memberships / viewers / billing)
- **Purpose.** Settings subnav: **network memberships** (per-hub, which identity you present,
  active/pending, leave), **private viewers** (scoped read grants — teacher/executor/circle, revoke),
  **billing** (hosted-vault plan via Stripe, supporter payouts, invoices).
- **② Feed.** Memberships, private-viewer grants, invoices, payout totals, payment method — **all
  real** (memberships from hub state, billing from Stripe).
- **③ Derived.** "Renews in N days", payout-after-fees.
- **④ State.** Leave hub (Confirm), revoke viewer (Confirm), grant viewer (Prompt/picker), update
  card (Stripe), view payouts.
- **Gotcha.** Each membership shows **which identity** is presented to that hub — tie to the identity
  model. Billing is **② from Stripe**; never fake amounts. Private viewers are real ACL grants that
  affect `Viewer`-visibility content.

## WORKBENCH (tools — several carry ACCURATE logic to port, §10.7)

### `Theourgia Divination.dc.html` — divination workbench (tarot lead)
- **Purpose.** Tarot table + interpretation pane, with a 5-tool switcher (tarot / I Ching / geomancy
  / runes / scrying) sharing one "cast" frame.
- **② Feed.** Deck definitions, the saved session (cards drawn + positions + interpretation), past
  sessions.
- **③ Derived.** The shuffle/draw (seeded RNG — store the seed so a reading is reproducible/auditable
  for "scientific illuminism"); spread layout positions.
- **④ State.** Tool switcher, draw/shuffle, write interpretation → saves a divination session
  (entry). I Ching & geomancy tools share the frame but their **engines live in Oracle** — reuse.
- **Gotcha.** A reading is a **record** (it gets logged, analyzed in Analytics, embedded via
  `/divination`). Persist the cast + seed, not just the rendered cards.

### `Theourgia Oracle.dc.html` — I Ching + geomancy caster (ACCURATE)
- **Purpose.** Interactive, **correct** I Ching (coin-cast 6 lines → hexagram via verified **King
  Wen** table; changing lines → becoming hexagram) and **Geomancy** (cast 4 Mothers → derive
  Daughters/Nieces/Witnesses/Judge; 16 correct figures with dot patterns + verdicts).
- **③ Derived — reuse verbatim.** The King Wen lookup and the geomancy XOR-derivation in this file
  are **verified correct**. Port them into a shared `divination/` util; don't re-derive. The dot
  patterns and figure names are canonical.
- **④ State.** Cast (with stored seed), read result, recast.
- **Gotcha.** This is a **reference implementation**. The Divination workbench's I Ching/geomancy
  tabs should call the *same* engine. A cast produces a **session record** (persist it).

### `Theourgia Sigil Studio.dc.html` — sigil workbench (ACCURATE math)
- **Purpose.** intent → kamea construction; 3-pane (method / canvas / properties). Builds a sigil by
  tracing letters of an intent over a planetary magic square.
- **③ Derived.** The **magic square (kamea)** and the **traced path** are computed. This math is
  shared with Talisman — lift it into one `kamea/` util.
- **④ State.** Method pick, intent input, canvas trace, properties → saves a sigil asset.
- **Gotcha.** Output is a **reusable asset** (embeddable via `/sigil`, printable via the sigil print
  sheet). The studio and the Talisman designer must share the same kamea engine and sigil-trace logic
  so a sigil looks identical wherever rendered.

### `Theourgia Talisman.dc.html` — talisman designer (ACCURATE)
- **Purpose.** 3-pane workbench: planetary virtue picker (Saturn/Jupiter/Mars…) drives a data-driven
  concentric talisman SVG — name-ring (Hebrew divine name) + kamea magic square + traced Intelligence
  sigil (obverse); planetary character + Intelligence ring (reverse). Properties rail: magic
  constant, the three spirits (Hebrew), election of time, suffumigation.
- **③ Derived.** Kamea + **magic constant** computed from the chosen planet; sigil traced over the
  square; name-ring text. All data-driven by the planet selection.
- **④ State.** Planet/virtue picker, obverse/reverse flip, properties → saves talisman asset →
  printable (Talisman print sheet).
- **Gotcha (the textPath fix — applies to all ring text).** Text on circular paths **must** set
  `textLength` = 2πr (the ring radius) and `lengthAdjust="spacing"` so glyphs distribute **evenly**
  around the full ring. Without it the text flows from the top and stops/overruns at the seam (ugly
  gap). This applies to Talisman, Circle, and the Talisman print sheet — bake it into your
  ring-text component.
- **Gotcha (radial-zone separation — ornaments vs ring text).** Every concentric ornament
  (warding pentagrams, sigil discs, seals) **must** sit in its own radial band, never at the same
  radius as a ring-text label — otherwise the glyphs render *under* the ornament and become
  illegible. Concretely: with names-of-power on a band at radius `RNAME`, place warding stars in the
  **outer boundary band** (between `R2` and `ROUT`), e.g. centre `(R2+ROUT)/2`, not straddling
  `RNAME`. Audit this on **any** circular figure: text and ornament zones may touch their shared ring
  stroke but must not overlap each other.

### `Theourgia Circle.dc.html` — magical circle builder (ACCURATE attributions)
- **Purpose.** 3-pane: tradition picker (Golden Dawn / Goetic / Hellenic) **re-attributes** the
  quarters + names; toggleable layers (names of power, quarters & elements, warding pentagrams,
  triangle of art); data-driven circle SVG (double boundary, Hebrew/Greek name-ring, quartered axes
  with elemental glyphs, warding pentagrams, central hexagram, external triangle of art).
- **③ Derived.** Quarter attributions, names, and glyph placements **derive from the chosen
  tradition** — this mapping is correct in the mockup; port it.
- **④ State.** Tradition picker, per-layer toggles → saves a circle diagram (printable/embeddable).
- **Gotcha.** Same ring-text rule as Talisman. The tradition→attribution table is real domain data —
  keep it in a data file, not inline.

### `Theourgia Workshop.dc.html` — generators hub (ACCURATE instruments)
- **Purpose.** Launcher cards (→ Sigil / Talisman / Circle) **plus 4 interactive instruments**: live
  **gematria** calculator (Latin order; full/ordinal/reduced), current **planetary hour** (computed
  from Date + coming hours), **barbarous-name** generator (PGM-style syllable pools, reroll),
  **sortilege** oracle (random cast).
- **③ Derived — reuse.** Gematria math and planetary-hour computation are correct here. **Lift
  gematria into the shared util the editor's `/gematria` block also uses; lift planetary-hour into
  the celestial util Today/Synchronicities/Ritual Feed use.** Don't duplicate.
- **④ State.** Each instrument is real interactive client logic.
- **Gotcha.** The instruments are genuinely functional, not mockups — keep them correct. Barbarous
  names: the syllable pools are the data; reroll is seeded for reproducibility if logged.

### `Theourgia Analytics.dc.html` — analytics / scientific illuminism
- **Purpose.** Tufte-aware: sparkline stat cards, a line chart, a practice heatmap, **saved studies**
  (queries the magician saves and re-runs).
- **② Feed.** All series come from **aggregation queries** over the practice record (entries,
  divinations, workings, synchronicities). Saved studies are stored query definitions.
- **③ Derived.** Sparkline/heatmap/line data are computed aggregations — never static arrays.
- **④ State.** Build/run/save a study; date-range; drill-in.
- **Gotcha.** This is a **query builder + viz** surface, not a static dashboard. The charts must be
  real (accessible: data tables behind viz, not color-only). "Saved studies" implies persisted,
  named, re-runnable queries.

### `Theourgia Synchronicities.dc.html` — synchronicity log
- **Purpose.** Quick-capture composer (charge selector, auto time/planetary-hour, place) + a
  date-grouped sign stream (glyph, reading, linked working/entity chip, open/confirmed/noted status)
  + a recurring-motifs rail (counts + bars) + a cluster note → Analytics.
- **② Feed.** Synchronicity entries (collection, date-grouped), recurring-motif aggregations, linked
  workings/entities.
- **③ Derived.** Auto-captured **planetary hour + time + place** at capture moment (§10.7); motif
  counts.
- **④ State.** Composer (charge, links → writes entry), status changes, motif drill-in.
- **Gotcha.** Shares the composer concept with the global Quick-Capture overlay — same write path.
  The auto planetary-hour is **③**, captured server/client-side at save, then stored with the entry.

### `Theourgia Transliterate.dc.html` — romanization helper (ACCURATE mapping)
- **Purpose.** Live Latin→Greek / Latin→Hebrew transliteration (digraph-aware: th→θ, sh→ש…; Greek
  final-sigma; Hebrew RTL), clickable per-script glyph palette (inserts), copy.
- **③ Derived — reuse.** The mapping + digraph handling + final-sigma + RTL logic is correct. **This
  is the engine for the editor's inline romanization helper** (§10.7) — lift it; don't reimplement in
  the editor.
- **④ State.** Input → live output, script toggle, palette insert, copy.
- **Gotcha.** Transliteration is a *helper*, not authoritative — the UI says "a guide, not gospel".
  Keep that humility; let users hand-correct. Extend to more scripts as needed (the brief lists
  Arabic/Devanagari/Coptic too).

---

# Part 4 · Surface catalog — Authoring, Specialized modes, Print

## AUTHORING (the Tiptap editor and its supports)

### `Theourgia Editor.dc.html` — block editor (Tiptap)
- **Purpose.** The writing surface: drop-cap prose plus **custom magical blocks** — ritual-log,
  quote/citation, gematria, sensation diagram — and a **slash menu** (`/sigil /chart /quote /gematria
  /entity /sensation /divination`). Inline language toolbar.
- **① Reusable.** This is a **Tiptap** instance. Each custom block is a Tiptap **node** with a render
  view + a serialized form (so Essay/Blog/Book can render it). The slash menu, the language toolbar,
  and the visibility selector (in the entry's meta) are shared.
- **② Feed.** The document itself (entry content), plus pickers' data: entity picker (entities +
  unified views), library picker (citations), template to start from.
- **③ Derived.** The `/gematria` block computes via the shared gematria util (§10.7); the
  `<entity-ref>` resolves a specific entity or a unified view; the language toolbar uses the
  transliteration engine.
- **④ State.** Editing, slash menu, block insertion/config, identity picker (who authors this),
  visibility selector, save/draft/publish.
- **Backend.** Tiptap JSON persisted as the entry body; custom nodes need matching server schema +
  HTML renderers for public views.
- **Gotcha.** The mockup shows some embeds (chart/sigil/divination) **stubbed in the slash menu** —
  those blocks still need full implementations. Every custom block must **round-trip**: edit form ↔
  stored JSON ↔ public-rendered HTML (the same blocks appear in Essay/Book). Don't build the editor
  view and forget the read renderer.

### `Theourgia Templates.dc.html` — template browser
- **Purpose.** Category filters (workings/divination/journal), template gallery cards (glyph, block
  count, use count, selectable), preview rail with block-structure skeleton + "Use this template" →
  Editor. (6 seed templates: evocation, daily LBRP, tarot, scrying, dream, pathworking.)
- **② Feed.** Templates collection (with usage counts), each template's block structure.
- **④ State.** Category filter, select → preview, "use" → opens Editor pre-filled with the block
  skeleton.
- **Gotcha.** "Use count" is **② real analytics**. The brief also wants a **drag-and-drop template
  *designer*** (compose a new template visually) — the mockup's "New template" is a stub; that
  authoring tool still needs building. Templates are the block-skeleton source the Editor consumes.

## SPECIALIZED MODES

### `Theourgia Trance Mode.dc.html` — trance / scrying
- **Purpose.** Minimal-chrome visionary mode: low-blue-light treatment, breathing timer, dim vision
  field, large text — for scrying logs and visionary work.
- **① Reusable.** A full-screen "mode" layout (no app shell), ambient timer.
- **③ Derived.** Timer state; the low-blue-light filter (a real color treatment, not a vibe — keep it
  within token-driven theming, possibly a dedicated mode layer).
- **④ State.** Start/stop breathing timer, capture a quick scrying note (writes an entry), exit.
- **Gotcha.** This is a **working mode used at night by candlelight** — contrast and minimum sizes
  still must meet a11y; "dim" is achieved via the palette, not by dropping below contrast floors.
  Reduced-motion must tame the breathing animation.

### `Theourgia Ritual Mode.dc.html` — ritual (hands-free)
- **Purpose.** Full-screen ritual script: huge Hebrew + transliteration, big step controls,
  hands-free progress.
- **② Feed.** The ritual **script** (steps, each with the working's text, the original-script lines,
  transliteration, optional rubric).
- **③ Derived.** Current-step index; transliteration (shared engine).
- **④ State.** Next/prev step (large touch targets; the brief mentions voice triggers — design for
  hands-free), progress, exit. Optionally logs completion → a working entry.
- **Gotcha.** Text is intentionally **huge** (read at arm's length). Targets ≥44px++. This renders a
  **real saved working/template** — it's the "perform" view of content authored in the Editor.

## PRINT (fixed-size parchment + real `@media print`)

### `Theourgia Print - Ritual Sheet.dc.html` — ritual sheet
- **Purpose.** Parchment ritual sheet with a pentagram diagram; print-grade.
- **① Reusable.** The **print sheet frame** primitive (fixed page size, parchment surface,
  `@media print` that strips app chrome) — shared by all three print surfaces.
- **② Feed.** The ritual content rendered onto the sheet.
- **④ State.** Paper-size selector, Print.
- **Gotcha.** Implement true print CSS (`@page` size/margins). The parchment is for screen preview;
  print output must be clean and ink-economical. This is used for **real ritual use** — legibility
  and correct script rendering matter.

### `Theourgia Print - Talisman & Sigil.dc.html` — consecration sheets
- **Purpose.** Two specimens behind a Talisman/Sigil toggle: a Jupiter **talisman** consecration
  sheet (drawn talisman — name-ring, kamea, traced sigil; virtue/metal/day/square/suffumigation
  table; consecration rite; signature line) and a **sigil** sheet (intent, reduced letters, traced
  sigil on the lunar square, charging + forgetting rite).
- **② Feed.** The talisman/sigil **asset** comes from the Talisman designer / Sigil studio (same
  kamea + trace engine), plus its correspondences table.
- **③ Derived.** Drawn figures are generated from the asset's parameters (not static SVG).
- **④ State.** Talisman/Sigil toggle, paper size, Print.
- **Gotcha.** Same **textPath even-distribution** rule as Talisman/Circle. These sheets render
  **real saved assets** — they are the print path for Studio/Designer output, not standalone art.

---

# Part 5 · Surface catalog — Network / hub / admin & Advanced (addendum) surfaces

These are the most architecturally loaded surfaces — federation, crypto, permissions, inheritance,
agents, bundles. Read §10 again before implementing any of them. **Resist the urge to ship the
badges as cosmetic** — most "status" here reflects real distributed-system or cryptographic state.

## NETWORK / HUB / ADMIN

### `Theourgia Ritual Feed.dc.html` — network group ritual feed
- **Purpose.** A hub's ritual schedule: list + calendar views; a detail-rich "next ritual" (order of
  service, materials, timezone + planetary hour, RSVP going/maybe/can't); upcoming list with
  per-ritual RSVP; post-ritual collective log; iCal-subscribe rail with QR.
- **② Feed.** Rituals collection (per hub), each with script/materials/participants; RSVP records;
  the collective log (merged participant notes).
- **③ Derived (important).** Each ritual time is stored **canonically (UTC)** and rendered in **each
  viewer's timezone + their local planetary hour** (§10.7). Two members see different local times for
  the same ritual — compute per viewer, never store a display string.
- **④ State.** List/calendar toggle, RSVP (writes), subscribe (generates a personal iCal feed URL +
  QR), add to collective log post-ritual.
- **Gotcha.** The iCal feed is a real per-user subscription URL. The collective log **merges** many
  participants' notes into one record — model the merge. Calendar-layer toggling applies here too.

### `Theourgia Membership.dc.html` — hub membership management (officers)
- **Purpose.** The admin half of a Hub: stats, **petitions to read** (admit/decline), a
  degree-filtered roster (identity glyph, office, degree, standing dot), by-degree breakdown,
  dues/standing rail.
- **② Feed.** Members collection (role/degree/office/standing), pending petitions (from the public
  Hub's petition-to-join), dues/standing aggregates.
- **④ State.** Admit (→ Confirm, creates membership at a degree) / decline a petition; manage a member
  (role/degree/standing); invite. Gated by **permissions** (only officers with the right perms).
- **Gotcha.** Two ends of one flow: petitions originate on the **public Hub** page; they resolve
  here. Members are **identities**, shown with the identity they present to this hub. Standing
  (good/dues-owing/suspended) is real state with downstream effects. Roster rows → **Profile**.

### `Theourgia Federation.dc.html` — federation peer browser (self-host admin)
- **Purpose.** Run your node's federation: this-instance card with a federation-mode toggle
  (open/invite/off + live note), a pending peer request, a connected-peers list (status dot+glow,
  trust badge, software, shared scope, latency, blocked peer), at-a-glance stats, a "what you share"
  rail → SSO.
- **② Feed.** Peers collection (each with software, trust, shared scope, **live reachability +
  latency**), pending requests, instance config.
- **③ Derived.** Peer **status/latency are live health checks** (poll/subscribe), not static dots.
- **④ State.** Federation mode toggle (changes who can peer), accept/reject a peer request, block a
  peer (Confirm), adjust shared scope.
- **Gotcha.** This is ActivityPub-style infrastructure. "Status" = real connectivity. Blocking is a
  real policy change. Pairs with **Health** (node status) and **SSO** (what you expose).

### `Theourgia SSO.dc.html` — SSO across networks
- **Purpose.** "Sign in with Theourgia" to a hub: a secure-authorization **consent screen** (pick
  which identity to present → live scopes "will see" / "never shared", with a Sophia-private caution),
  optional permission toggles, a connected-networks rail (SSO history + a pending access request),
  themed revoke confirm.
- **② Feed.** The requesting hub + requested scopes; the user's identities; connected-networks
  history; pending access requests.
- **③ Derived.** The **live "will see / never shared" scope preview** updates with the chosen identity
  and toggles — compute from the actual grant that would result.
- **④ State.** Identity-to-present picker, scope toggles, authorize, revoke (Confirm).
- **Gotcha.** This is an **OAuth-style consent** screen — the scopes shown must equal what's actually
  granted (no theater). Presenting identity A vs. B to a hub is the unlinkability-sensitive choice;
  show exactly what each reveals. Hubs requiring approval feed the access-request queue.

### `Theourgia Newsletter Composer.dc.html` — newsletter composer (admin)
- **Purpose.** Split editor | live email preview: subject + preview text, body toolbar with an
  embedded linked-essay block, parchment-rendered email (Almanac masthead), audience selector
  (all/supporters), send-as identity.
- **② Feed.** The draft issue, audience segments (subscriber counts), linked essays, send-as identity.
- **③ Derived.** Live email preview rendered from the draft; recipient count from the audience.
- **④ State.** Compose, pick audience, pick identity, send now **or schedule** (→ Scheduler), test
  send.
- **Gotcha.** Email rendering is its own constraint (table layout, inlined styles, client quirks) —
  the parchment preview must match what actually sends. Output publishes to the **Newsletter
  archive**; scheduling hands off to **Scheduler**.

### `Theourgia Scheduler.dc.html` — time-released content scheduler
- **Purpose.** "What's queued" (a feature next-release card + typed releases: post/newsletter/
  publication) + a **tradition-calendar picker** (by-date vs by-tradition → resolves Solstice/Beltane
  to a real date + planetary hour) + curriculum timed-unlock + a calendar view + themed
  release-now/cancel confirms.
- **② Feed.** Scheduled releases collection (mixed types), curriculum units + unlock dates.
- **③ Derived (notable).** The **tradition-date resolver** turns "Beltane 2027" into a concrete
  timestamp (+ planetary hour) — real astronomical/calendar computation (§10.7). Timezone-aware.
- **④ State.** Schedule/reschedule, "release now" (Confirm-constructive), cancel (Confirm),
  by-date↔by-tradition toggle.
- **Gotcha.** One queue spans entries, posts, newsletter issues, publications — model a polymorphic
  "scheduled release". The tradition resolver is a feature, not decoration; it must be correct.

### `Theourgia Permissions.dc.html` — admin permissions panel
- **Purpose.** Role rail + a per-role **grouped permission matrix** (30+ granular perms grouped by
  domain), **preview-as-role**, permission templates (coven/lodge/study-group/scholarly).
- **② Feed.** Roles (incl. custom), the permission catalog (grouped), each role's grants, templates.
- **③ Derived.** "Preview as role X" **recomputes the whole UI's affordances** as if you held only
  that role — it's a real capability simulation, used to verify config.
- **④ State.** Toggle perms per role, create/clone role, apply a template, enter/exit preview-as.
- **Gotcha.** Permissions are **enforced server-side** — this UI edits policy; it doesn't *implement*
  the gate. "Preview as" must mirror the real enforcement. Permission-denied elsewhere uses a
  **non-punitive** dialog explaining what's needed + the escalation path (humane voice).

## ADVANCED / ADDENDUM SURFACES

### `Theourgia Identities.dc.html` — multi-identity selector & management
- **Purpose.** Top-nav "acting-as" switcher + identity cards (incl. archived) + defaults-by-surface +
  a write-time picker demo + a detail/edit rail with keypair + a themed archive confirm.
- **② Feed.** Identities (avatar/name/bio/keypair/defaults), archived ones.
- **④ State.** Switch acting-as (global — affects authoring + nav), edit identity, set per-surface
  default, archive (Confirm), generate/rotate keypair.
- **Gotcha.** Acting-as is **global state** consumed by the Editor, Blog, Profile, memberships, SSO.
  Each identity's keypair is real (signs that identity's content/attestations). Archived ≠ deleted.
  The unlinkable pseudonym is a first-class identity with signing deliberately off.

### `Theourgia Lineage.dc.html` — lineage attestation & verification
- **Purpose.** Trust web: verified / self-declared / revoked states, in-browser signature
  verification.
- **② Feed.** Attestations (claim, claimant identity, signatures, counter-signatures), authority
  profiles.
- **③ Derived.** Each attestation's **state is a real signature check**; "verify" fetches the
  authority's public key and validates **client-side** (§10.5).
- **④ State.** Verify a signature, follow to an authority's profile, declare/relinquish an
  attestation (signs/revokes).
- **Gotcha.** Three visually-distinct states (unsigned / counter-signed / revoked) must be **derived
  from crypto**, never set by hand. Counter-signatures link to the **authority's** profile, which has
  its own attestations (recursive trust web).

### `Theourgia Memorial.dc.html` — memorial / digital-inheritance mode
- **Purpose.** A vault flipped to in-memoriam: quiet desaturated treatment, a candle, preserved
  writings, remembrances. Only public content; no active interactions; preserved permanently.
- **② Feed.** The deceased identity's public content, remembrances (others' contributions).
- **③ Derived.** The memorial **state** is triggered by the inheritance check-in mechanic (§10.6).
- **④ State.** Mostly read-only; remembrances may be added. **The executor/check-in setup wizard is
  still TODO** (the brief's "executor setup wizard" + check-in config + posthumous-release marking).
- **Gotcha.** Tone-critical. Desaturation is a **mode treatment** (token layer), still a11y-compliant.
  This is the *output* of digital inheritance; build the **executor wizard** (key-share explanation,
  "have this conversation", check-in interval) as the missing input side.

### `Theourgia Wellbeing.dc.html` — crisis-aware nudge (opt-in)
- **Purpose.** Settings→Wellbeing: an **opt-in** toggle (off by default), privacy guarantees (read on
  device / never logged / never modal), a sensitivity threshold (ask-only / sustained-shift / acute),
  regional resources (Intl/US/UK/Greece — real crisis lines + a magick-literate directory), a live
  nudge preview (calm vigil-lamp, never red), per-display mute.
- **② Feed.** Regional resource lists (community-maintained), the user's opt-in + threshold + mute
  settings.
- **③ Derived.** Any detection runs **on-device, never logged** (privacy guarantee — honor it
  literally). The nudge appears only per threshold.
- **④ State.** Opt-in toggle, threshold, region, mute duration.
- **Gotcha.** The single most tone-sensitive surface. **Never modal, never alarming, never red, never
  logged.** Off by default. The nudge is a small dismissible card with "a note, if it's welcome"
  framing — get the copy from the maintainer; do not improvise crisis language.

### `Theourgia Health.dc.html` — self-host health dashboard
- **Purpose.** Admin-only node health: overall status + a service grid (operational / degraded /
  expiring) — API, federation reachability, backups, last migration, plugin health, agent daemon,
  Cloudflare token, cert expiration countdown.
- **② Feed.** Live service statuses (real health checks / metrics endpoint).
- **③ Derived.** Overall status rolls up the grid; **cert/token expiry countdowns** compute from
  expiry timestamps.
- **④ State.** Refresh, drill into a service, run a check.
- **Gotcha.** Everything here is **live ② / ③** — there is no static content. "Operational" must mean
  a real probe passed. Pairs with **Federation** (peer reachability) and **Docs** (self-hosting).

### `Theourgia Agents.dc.html` — AI agent surfaces
- **Purpose.** Agent list (status / cost / model), capability **allowlist**, a token-usage dashboard,
  an activity log.
- **② Feed.** Installed agents (status, model, cost cap), per-agent capabilities, **token usage**
  (input/output/cache; daily/weekly/monthly; fresh-vs-resume), the human-readable activity log.
- **③ Derived.** Cost from tokens×rates; "approaching cap" thresholds (→ non-blocking Toast; **at**
  cap → modal).
- **④ State.** Enable/dormant/disable, edit capability allowlist (consent), set model + cost cap,
  open memory directory, "wake agent" (context-sensitive, e.g. on a tarot session).
- **Gotcha.** **BYO keys — "your keys never leave your instance"**; surface that prominently.
  Capability consent is **browser-extension-style**: the user sees every capability before
  activating, granular accept/decline. The **install/consent modal + memory-file editor are TODO**.
  The activity log is human-readable narration, not raw logs.

### `Theourgia Bundles.dc.html` — MBF bundle browser
- **Purpose.** Browse/share magickal systems: card grid, type filters (pantheon/tradition/ritual/
  deck/sigil library), tier badges (Official/Community/Unverified), signature status, a closed-
  tradition notice.
- **② Feed.** Bundles collection (manifest summary, tier, tradition tags, install count, updated,
  maintainer), filterable/searchable.
- **③ Derived.** **Signature/tier is a real verification state.** Closed-tradition flag comes from the
  manifest and changes available actions.
- **④ State.** Filter/search → bundle detail → install. (The standalone **bundle detail page** is
  partially TODO — the browser + install wizard exist.)
- **Gotcha.** Tier/signature are trust signals — derive from verification, don't fake the badge.
  Closed-tradition bundles **block public-share affordances** and show a respect-source notice.

### `Theourgia Bundle Install.dc.html` — MBF install wizard
- **Purpose.** 6 steps: preview contents → license/attribution → mode (sandbox-first **recommended**
  / direct) → select items (whole bundle or pick pieces) → resolve alias conflicts → confirm.
- **② Feed.** The bundle manifest + contents; the user's existing entities (for collision detection).
- **③ Derived.** Conflict detection (name collisions vs. existing entities); what-will-change preview.
- **④ State.** Step nav, item selection (piecemeal), per-conflict alias resolution (relate vs.
  distinct, default **distinct**), choose sandbox vs. direct, confirm (writes — sandbox or vault).
- **Gotcha.** **Sandbox-first is the recommended default.** Alias conflicts reuse the **import-alias
  prompt** from Entity Profile. Piecemeal import (pull one ritual from a pantheon) is a real
  requirement — model selection granularly.

### `Theourgia Sandbox.dc.html` — MBF sandbox view
- **Purpose.** Run imported content in **visible isolation**: distinct blue sandbox chrome + hatched
  background, the bundle's items (entities/templates/library, name-clash flags), a
  permissions-requested panel (granted/review/blocked, **no network**), an on-import verdict (new
  items / clashes / self-signed). Discard vs. Import-for-real.
- **② Feed.** Sandbox contents (isolated copy), requested permissions, conflict summary.
- **③ Derived.** The verdict (counts, clashes, signature) computed from the sandbox vs. the live
  vault.
- **④ State.** Open/read sandbox items, **Discard** (vanishes, no trace) vs. **Import for real**
  (→ resolve conflicts → vault).
- **Gotcha.** Isolation is **real**, not a skin: sandbox content cannot touch the live vault and has
  **no network access** until promoted. The distinct chrome is the affordance that the user is *not*
  in their real vault — keep it unmistakable.

### `Theourgia Interaction Patterns.dc.html` — visibility selector & sensation diagram (spec)
- **Purpose.** Spec/demo for two cross-cutting controls: the **VisibilitySelector**
  (Personal/Chosen-viewers/Network/Public/Sealed — colored rungs + live explanation) and the
  **SensationDiagram** (clickable body map; tap a point, tap again to cycle cool/warm/light quality;
  marked-points list).
- **① Reusable — both are shared components.** VisibilitySelector goes on **every content composer**
  (entry, post, publication, quick-capture) and writes the item's real visibility/ACL/encryption
  state (Sealed = encrypt). SensationDiagram is the editor's `/sensation` block (stores marked points
  + qualities on the entry).
- **④ State.** Visibility pick (consequential — drives access + crypto); sensation point cycling.
- **Gotcha.** These are **not a one-off page** — they're component specs. The visibility levels carry
  real meaning (§10.1): `Sealed` triggers encryption; `Viewer` ties to private-viewer grants;
  `Network` to memberships. Color is paired with icon + label (a11y). The sensation diagram is data
  capture, not decoration — persist the points.

---

# Part 6 · Appendices

## A · Domain glossary (so the copy and the model make sense)

| Term | Meaning |
|---|---|
| **Vault** | One practitioner's Theourgia instance/account (self-hosted or hosted). |
| **Identity** | An author persona within a vault; has its own avatar, bio, **signing keypair**. A vault has many; content is authored *as* one. |
| **Hub** | A network/order (e.g. an OTO lodge, a Hellenic group). Has a public face + private membership + a ritual schedule. |
| **Federation** | Peer relationships between instances (ActivityPub-style). "Peers" are other servers. |
| **SSO** | "Sign in with Theourgia" — present a chosen identity to a hub with explicit, scoped consent. |
| **Visibility** | Per-item access level: Personal / Viewer / Network / Public / Sealed. |
| **Sealed** | End-to-end encrypted at rest under the user's key (zero-knowledge). |
| **Lineage attestation** | A signed claim of initiation/degree/teacher/membership; may be counter-signed by an authority or revoked. |
| **Entity** | A god/spirit/angel/demon/saint/ancestor record with correspondences. |
| **Alias graph** | Typed relationships between entities (same-as / aspect-of / syncretic-with / epithet-of). |
| **Unified view** | A saved union of entities (e.g. `Hekate-all`). The `<entity-ref>` block can target one. |
| **MBF** | Magickal Bundle Format — a shareable package of a magickal system; installed via a sandbox-first flow. |
| **Sandbox** | An isolated space to try MBF content with no vault access and no network until promoted. |
| **Kamea** | A planetary magic square; sigils are traced over it; it has a magic constant. |
| **Gematria** | Letter-to-number summation (full / ordinal / reduced) for a word/name. |
| **Geomancy** | Divination by 16 figures: 4 Mothers cast → Daughters/Nieces/Witnesses/Judge derived. |
| **Planetary hour** | The planet ruling the current hour, from local sunrise/sunset + the day's ruler. |
| **Barbarous names** | PGM-style voces magicae (untranslatable ritual vocables). |
| **Trance / Ritual mode** | Full-screen working modes (scrying / hands-free ritual performance). |
| **Memorial mode** | A vault flipped to in-memoriam after a digital-inheritance trigger. |
| **The Almanac** | "The Theurgist's Almanac" — the product's newsletter. |
| **Officer / degree / standing** | A hub member's office, initiatory grade, and dues/membership status. |

## B · Master data-source index — what feeds what

Quick lookup of **where each kind of data comes from**. `client` = pure browser computation;
`server` = API/DB; `crypto` = signature/key operation; `stripe` = payments; `ephemeris` =
astronomical; `health` = live probes.

| Data | Source | Notes |
|---|---|---|
| Planetary hour / lunar phase / transits | `ephemeris` + `client` | Needs user lat/long; recompute on timer. |
| Multi-calendar date rendering | `client` | From canonical UTC timestamp. |
| Gematria values | `client` | Shared util; used in Workshop + editor `/gematria`. |
| I Ching hexagram / geomancy figures | `client` | Verified engines in Oracle; reuse. |
| Kamea + magic constant + sigil trace | `client` | Shared by Sigil Studio, Talisman, print sheets. |
| Transliteration | `client` | Shared by Transliterate + editor language toolbar. |
| Entries / synchronicities / divination sessions | `server` | Core collections; filterable/grouped queries. |
| Entity records + alias edges + unified views | `server` | Graph; typed edges. |
| Library items + citations | `server` | Referenced by entities + quote blocks. |
| Analytics series / saved studies | `server` | Aggregation queries, persisted study defs. |
| Identities + keypairs | `server` + `crypto` | Acting-as is global state. |
| Visibility / Sealed status | `server` + `crypto` | Sealed = encryption operation. |
| Lineage attestations + verification | `server` + `crypto` | "Verify" validates in-browser. |
| Hub profile / members / petitions / officers | `server` | Public Hub vs. admin Membership. |
| Group ritual times → local | `server` (canonical) + `client` (tz/hour) | Per-viewer rendering. |
| RSVP / collective log | `server` | Writes; log merges participants. |
| Federation peers + reachability/latency | `server` + `health` | Live status, not static dots. |
| SSO scopes / connected networks | `server` + `crypto` | Consent = real grant. |
| Permissions / roles / preview-as | `server` | Enforced server-side; UI edits policy. |
| Blog posts / essays / newsletter issues | `server` | Per-identity; public render. |
| Scheduled releases / tradition-date resolve | `server` + `ephemeris` | Polymorphic queue. |
| Book content / index / glossary | `server` + `client` | Index/glossary auto-generated. |
| Book formats / prices / payouts / invoices | `stripe` | Never fake amounts. |
| Agents / token usage / cost | `server` | BYO keys; cost from tokens×rates. |
| Bundle manifest / tier / signature | `server` + `crypto` | Trust signals. |
| Health service grid / expiries | `health` | All live; nothing static. |
| Wellbeing detection | `client` only, **never logged** | Privacy guarantee is literal. |
| Theme / mode / a11y prefs | `server` + `localStorage` | Mirror for first-paint. |

## C · Suggested build order (dependency-first)

1. **Token layer + Tailwind preset** (`tokens/`) wired into the app; theme/mode/a11y switching on
   `<html>`; persistence. *Everything* depends on this.
2. **Icon/Glyph component** over the sprite; begin the subject-glyph expansion (§6).
3. **Primitives** (Foundations spec): Button, Field, Switch, Segmented, Chip, Card, Badge, Stat,
   Progress, EmptyState, Avatar/medallion, Dot.
4. **Overlay/dialog family** (Overlays spec, §7) — unblocks every surface; kills native dialogs.
5. **AppShell + VaultNav** (with the scroll convention) and the **public chrome** layout.
6. **Shared logic utils**: celestial (planetary hour/lunar), gematria, I Ching, geomancy, kamea,
   transliteration — porting the ACCURATE engines (§10.7).
7. **VisibilitySelector** + the **editor** with its custom blocks (round-trip!).
8. Then surfaces, roughly: Today → Journal → Entities/Entity Profile → Library → Settings/Account →
   Workbench tools → Public (Blog/Essay/Newsletter/Profile/Hub/Book/Docs) → Network/hub/admin →
   Advanced (Identities/Lineage/Bundles/Sandbox/Agents/Federation/SSO/Permissions/Health/
   Memorial/Wellbeing).
9. **Print** surfaces and the **specialized modes** last (they consume content authored earlier).

## D · Known TODOs carried from the design phase (not yet mocked, or stubbed)

These were flagged during design and still need building:

- **Executor setup wizard** + check-in mechanic config + posthumous-release marking (input side of
  **Memorial**).
- **Bundle detail page** (standalone) — browser + install wizard exist; the detail page is partial.
- **Drag-and-drop template *designer*** — Templates *browser* exists; the visual composer is a stub.
- **Editor embeds** — `/chart`, `/sigil`, `/divination` blocks are stubbed in the slash menu; build
  full blocks + their read-renderers.
- **Agent install/consent modal** + **memory-file editor**.
- **Subject-glyph icon expansion** (planetary/zodiac/decan/lunar) into the engraving sprite.
- **Per-script input methods** beyond transliteration (Arabic/Devanagari/Coptic), if required.
- **Loading / empty / error states** for *every* collection (the mockups show the happy path only).

## E · QA checklists (run per surface before "done")

**Reuse / data discipline**
- [ ] No sample data from the mockup shipped; every ②/③ value is wired to its source (App. B).
- [ ] Every list has loading, empty (humane voice), and error states.
- [ ] No hard-coded date/time/celestial/gematria value — all derived and recomputed as needed.
- [ ] Shared components used (no re-implementation of shell, dialogs, primitives, selectors).
- [ ] No raw hex/px-of-color — only tokens; new colors added as tokens.

**Hard rules**
- [ ] No `alert()`/`confirm()`/`prompt()` anywhere — themed dialogs only.
- [ ] No emoji decoration, no spinner-as-feature, no purple gradients / occult kitsch.
- [ ] Copy passes the Style Guide voice; errors are humane and blameless.

**Accessibility (WCAG 2.2 AA)**
- [ ] Contrast passes in base/hel/thel × dark/light, and with `high` + `cvd` on.
- [ ] Full keyboard path; visible focus; dialogs focus-trap + ESC; menus arrow-navigable.
- [ ] Color never the only cue (icon/shape/label paired).
- [ ] 200% zoom with no horizontal scroll; reduced-motion honored; form errors announced.
- [ ] Landmark roles + labelled controls; `aria-pressed`/`aria-current` on toggles/nav.

**i18n / RTL / print**
- [ ] Copy via i18n; Hebrew/Arabic set `dir="rtl"` and mirror layout; mixed-script runs correct.
- [ ] Per-script faces applied; minimum sizes respected.
- [ ] Print surfaces: real `@page`, clean output, crop/bleed where specified.

**Crypto / distributed truth (where applicable)**
- [ ] Signature/verification/tier/standing/health reflect *real* state, not cosmetic badges.
- [ ] Visibility `Sealed` performs encryption; `Viewer`/`Network` tie to real grants/memberships.
- [ ] Sandbox isolation is real (no vault access, no network until promote).

---

*End of onboarding. Keep `CLAUDE.md` (locked decisions), `PROGRESS.md` (surface manifest), the
brief + addendum (`uploads/`), and `tokens/README.md` (font/token rationale) alongside this file.
When in doubt about intent, ask Sophia — the mockups answer "what does it look like"; this document
answers "what does it mean", and she answers "what should it become".*
