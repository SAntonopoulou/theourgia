# Theourgia — Data Contracts, API & Component Reference

> Companion to **`agent_onboarding.md`**. That file answers *"what does each surface mean"*; this one
> gives you the concrete shapes to build against — TypeScript models, a REST sketch, the shared
> component inventory with prop signatures, and the computed-engine function signatures.
>
> **These are a starting contract, not gospel.** They encode the intent visible in the 50 mockups +
> the brief/addendum. Where a real implementation needs a field the mockup didn't show, add it — but
> keep the *names and meanings* here so the surfaces stay mutually consistent. When two surfaces touch
> the same data (e.g. Entity Profile + Bundle Install both touch alias edges), they MUST use the same
> type. Don't fork shapes per surface.

---

## 0 · Conventions

```ts
// Every persisted record
type ID = string;                 // opaque, server-issued (ULID/UUID); never a display value
type ISO = string;                // ISO-8601 UTC timestamp, e.g. "2027-05-01T13:00:00Z"
type Markdown = string;           // or Tiptap JSON where noted
type Hex = string;                // signing/hash hex
type Lang = "en" | "el" | "he" | "ar" | "hi" | "cop" | string; // BCP-47-ish

interface Meta {
  id: ID;
  createdAt: ISO;
  updatedAt: ISO;
  deletedAt?: ISO | null;         // soft-delete; never hard-delete user practice content
}
```

**Rules baked into every model below.**
- **All timestamps are canonical UTC.** Display in the viewer's timezone + chosen calendar at render
  time — never store a formatted string. (Group ritual times, scheduler, planetary hours.)
- **Authorship is by identity, not account.** Anything authored carries `identityId`, resolved against
  the acting-as identity at write time.
- **Visibility travels with content** (`visibility` + `acl`) and may imply encryption (`Sealed`).
- **Signed things carry a detached signature**, verifiable client-side against the signer identity's
  public key. Never trust a server-set "verified" boolean alone.
- **Soft-delete only** for practice content; `deletedAt` set, excluded from queries by default.

---

## 1 · Identity, account, visibility, crypto

```ts
interface Vault extends Meta {
  handle: string;                 // instance/account handle
  hosting: "self" | "hosted";
  encryption: EncryptionConfig;   // which content types are sealed
  memorial?: MemorialState | null;
}

interface Identity extends Meta {
  vaultId: ID;
  name: string;
  bio?: Markdown;
  avatarUrl?: string | null;      // null → render generated glyph medallion
  glyph?: string;                 // optional sigil/symbol id for the medallion
  signing: KeyPair;               // this identity's keypair
  signingEnabled: boolean;        // false for a deliberately-unlinkable pseudonym
  archived: boolean;              // archived ≠ deleted; cannot author, still referenced
  defaultsBySurface: Record<SurfaceKey, ID | null>; // which identity is default where
}

type SurfaceKey =
  | "journal" | "blog" | "publication" | "newsletter"
  | "ritualFeed" | "synchronicity" | "divination";

interface KeyPair {
  algo: "ed25519";
  publicKey: Hex;
  // privateKey NEVER leaves the instance; not serialized to the client in plaintext
  createdAt: ISO;
  rotatedFrom?: Hex | null;       // prior public key, for rotation history
}

// The five-rung control on every composer (VisibilitySelector)
type Visibility = "personal" | "viewer" | "network" | "public" | "sealed";

interface ACL {
  visibility: Visibility;
  viewerGrantIds?: ID[];          // when "viewer": which PrivateViewer grants may read
  networkHubIds?: ID[];           // when "network": which hubs may read
  sealed?: SealedEnvelope | null; // present iff visibility === "sealed"
}

interface SealedEnvelope {
  algo: "xchacha20poly1305";
  // content stored ciphertext; key wrapped to the identity's key(s)
  wrappedKeys: { recipientPubKey: Hex; wrapped: Hex }[];
  nonce: Hex;
}

interface EncryptionConfig {
  // per content-type zero-knowledge toggles (Settings → encryption, dangerous)
  sealedTypes: ContentType[];     // e.g. ["dream", "shadow-work"]
  recoveryHintSet: boolean;       // user acknowledged key-loss risk
}

interface PrivateViewer extends Meta {
  vaultId: ID;
  scope: "teacher" | "executor" | "circle" | "custom";
  granteeLabel: string;           // human label; may be an external person
  granteePubKey?: Hex | null;     // for sealed sharing
  contentFilter: ContentQuery;    // what this viewer may read
  revokedAt?: ISO | null;
}

interface SSOGrant extends Meta {
  hubId: ID;
  presentedIdentityId: ID;        // which identity the user shows this hub
  scopes: SSOScope[];             // exactly what is granted == what consent screen showed
  status: "active" | "pending" | "revoked";
}
type SSOScope =
  | "profile.read" | "memberships.read" | "rituals.rsvp"
  | "content.network.read" | "publish.network";
```

---

## 2 · Content: entries & the custom blocks

```ts
type ContentType =
  | "journal" | "ritual-log" | "dream" | "scrying" | "pathworking"
  | "shadow-work" | "divination" | "synchronicity";

interface Entry extends Meta {
  identityId: ID;
  type: ContentType;
  title?: string;
  body: TiptapDoc;                // Tiptap JSON; custom nodes below
  acl: ACL;
  tags: string[];
  entityRefs: EntityRefTarget[];  // entities/unified-views mentioned
  citations: ID[];                // LibraryItem ids
  templateId?: ID | null;         // template this was started from
  // derived/captured at save:
  capturedContext?: CelestialStamp; // planetary hour/lunar/place at write time
}

interface TiptapDoc { type: "doc"; content: TiptapNode[]; }
interface TiptapNode { type: string; attrs?: Record<string, unknown>; content?: TiptapNode[]; text?: string; marks?: unknown[]; }

// Custom Tiptap nodes — each MUST round-trip: edit form ↔ JSON ↔ public HTML render
interface RitualLogNode  { type: "ritualLog"; attrs: { steps: RitualStep[]; outcome?: string } }
interface QuoteCiteNode  { type: "quoteCitation"; attrs: { libraryItemId: ID; locator?: string; text: Markdown } }
interface GematriaNode   { type: "gematria"; attrs: { input: string; system: GematriaSystem; value: number /*derived*/ } }
interface SensationNode  { type: "sensation"; attrs: { points: SensationPoint[] } } // /sensation block
interface EntityRefNode  { type: "entityRef"; attrs: { target: EntityRefTarget } }
interface SigilNode      { type: "sigil"; attrs: { assetId: ID } }       // embed a saved sigil asset
interface ChartNode      { type: "chart"; attrs: { chartId: ID } }       // astro chart (TODO block)
interface DivinationNode { type: "divination"; attrs: { sessionId: ID } }// embed a reading

type EntityRefTarget =
  | { kind: "entity"; entityId: ID }
  | { kind: "unifiedView"; unifiedViewId: ID };

interface SensationPoint {
  // body map: normalized coords + cycling quality
  x: number; y: number;           // 0..1 over the body diagram
  quality: "cool" | "warm" | "light";
  note?: string;
}

interface RitualStep { text: Markdown; original?: string; lang?: Lang; transliteration?: string; rubric?: string }
```

---

## 3 · Practice records (divination, synchronicity, assets)

```ts
interface DivinationSession extends Meta {
  identityId: ID;
  tool: "tarot" | "iching" | "geomancy" | "runes" | "scrying";
  seed: string;                   // store the RNG seed → reading is reproducible/auditable
  cast: TarotCast | IChingCast | GeomancyCast | RuneCast | ScryNote;
  interpretation: Markdown;
  acl: ACL;
}

interface TarotCast { spread: string; cards: { positionId: string; cardId: string; reversed: boolean }[] }
interface IChingCast { lines: (6|7|8|9)[]; primary: number /*1..64 King Wen*/; becoming?: number; changing: number[] }
interface GeomancyCast { mothers: GeoFigure[]; daughters: GeoFigure[]; nieces: GeoFigure[]; witnesses: [GeoFigure,GeoFigure]; judge: GeoFigure }
type GeoFigure = { name: string; rows: [1|2,1|2,1|2,1|2] } // 4 rows, 1=single dot / 2=double
interface RuneCast { set: string; runes: { positionId: string; runeId: string; merkstave: boolean }[] }
interface ScryNote { vision: Markdown; durationSec?: number }

interface Synchronicity extends Meta {
  identityId: ID;
  reading: Markdown;
  charge: "minor" | "notable" | "striking";
  status: "open" | "confirmed" | "noted";
  motifs: string[];               // recurring-motif tags → aggregated in rail + Analytics
  links: { workingId?: ID; entityRef?: EntityRefTarget };
  capturedContext: CelestialStamp; // auto time + planetary hour + place at capture
  acl: ACL;
}

// Generated magical assets (shared by studio/designer + print + editor embeds)
interface SigilAsset extends Meta {
  identityId: ID;
  intent: string;
  method: "kamea" | "rose-cross" | "free";
  square?: PlanetaryName;         // when kamea: which planetary square
  trace: { x: number; y: number }[]; // path over the square (normalized)
  acl: ACL;
}
interface TalismanAsset extends Meta {
  identityId: ID;
  planet: PlanetaryName;
  obverse: TalismanFace; reverse: TalismanFace;
  election?: ISO;                 // chosen time of construction
  suffumigation?: string;
  acl: ACL;
}
interface TalismanFace { rings: RingSpec[]; centralFigure?: string }
interface RingSpec { radius: number; text?: string; script?: Lang; glyphs?: string[] }

interface CircleDiagram extends Meta {
  identityId: ID;
  tradition: "golden-dawn" | "goetic" | "hellenic";
  layers: { namesOfPower: boolean; quarters: boolean; wardingPentagrams: boolean; triangleOfArt: boolean };
  acl: ACL;
}
```

---

## 4 · Entities, alias graph, library

```ts
interface Entity extends Meta {
  class: "god" | "spirit" | "angel" | "demon" | "saint" | "ancestor" | "other";
  name: string;
  tradition: string[];            // e.g. ["hellenic","ptgm"]
  planet?: PlanetaryName;
  correspondences: Correspondence[];
  glyph?: string;                 // medallion glyph
  libraryRefs: ID[];              // citations
}
interface Correspondence { kind: "planet"|"element"|"metal"|"color"|"number"|"day"|"incense"|"plant"|"stone"|string; value: string }

interface AliasEdge extends Meta {
  fromEntityId: ID; toEntityId: ID;
  relation: "same-as" | "aspect-of" | "syncretic-with" | "epithet-of";
  // edges are typed and meaningful; default on import collision = DON'T create (keep distinct)
}

interface UnifiedView extends Meta {
  identityId: ID;
  label: string;                  // e.g. "Hekate-all"
  memberEntityIds: ID[];          // union targeted by <entityRef kind:"unifiedView">
}

interface LibraryItem extends Meta {
  title: string;
  author?: string;
  category: "primary-source" | "text" | "deck" | "grimoire" | "modern" | string; // → spine color/shelf
  lang: Lang;
  year?: number;
  // referenced by entities + quoteCitation blocks
}
```

---

## 5 · Publishing (blog, essay, newsletter, book/publication, templates)

```ts
interface BlogPost extends Meta {
  identityId: ID;
  title: string;
  body: TiptapDoc;
  status: "draft" | "scheduled" | "published";
  publishedAt?: ISO | null;
  acl: ACL;                       // typically public, but supports network-only
  tags: string[];
}

interface NewsletterIssue extends Meta {
  identityId: ID;                 // send-as identity
  subject: string; previewText: string;
  body: TiptapDoc;                // rendered to email-safe HTML on send
  audience: "all" | "supporters";
  status: "draft" | "scheduled" | "sent";
  scheduledFor?: ISO | null;
  linkedEssayIds: ID[];
}

interface Publication extends Meta {  // the print-book pipeline
  identityId: ID;
  title: string; subtitle?: string;
  chapters: { id: ID; title: string; body: TiptapDoc }[];
  generated: { index: IndexEntry[]; glossary: GlossaryEntry[] }; // ③ auto, editable pre-publish
  formats: PublicationFormat[];   // print/ebook/PDF — prices via Stripe
  status: "draft" | "preview" | "published";
}
interface PublicationFormat { kind: "hardcover"|"paperback"|"ebook"|"pdf"; priceCents?: number; stripePriceId?: string }
interface IndexEntry { term: string; refs: string[] }
interface GlossaryEntry { term: string; definition: Markdown }

interface Template extends Meta {
  identityId?: ID | null;         // null → built-in seed template
  category: "workings" | "divination" | "journal";
  name: string; glyph?: string;
  blocks: TiptapNode[];           // the skeleton the Editor pre-fills
  useCount: number;               // ② real analytics
}
```

---

## 6 · Network: hubs, membership, rituals, federation, permissions

```ts
interface Hub extends Meta {
  name: string; tradition: string;
  publicProfile: { about: Markdown; offices: Office[]; requiresApproval: boolean };
  federation?: { federated: boolean; peerScope?: string[] };
}
interface Office { title: string; holderMembershipId?: ID }

interface Membership extends Meta {
  hubId: ID;
  identityId: ID;                 // member presents THIS identity to the hub
  role: ID;                       // → Role
  degree?: string;                // initiatory grade
  office?: string;
  standing: "good" | "dues-owing" | "suspended";
  status: "active" | "pending";   // pending = a petition awaiting officer action
}

interface Petition extends Meta {  // originates on public Hub, resolved in Membership admin
  hubId: ID; identityId: ID; message?: Markdown; status: "pending" | "admitted" | "declined";
}

interface Ritual extends Meta {
  hubId: ID;
  title: string;
  startsAt: ISO;                  // canonical UTC; render per viewer tz + local planetary hour
  durationMin: number;
  orderOfService: RitualStep[];
  materials: string[];
  rsvps: RSVP[];
  collectiveLog?: { entries: { membershipId: ID; note: Markdown; at: ISO }[] }; // merged after
  icalUid: string;
}
interface RSVP { membershipId: ID; response: "going" | "maybe" | "cant"; at: ISO }

interface FederationPeer extends Meta {
  url: string; software?: string;
  trust: "trusted" | "known" | "blocked";
  sharedScope: string[];
  // live (③ health), not stored display:
  reachable?: boolean; latencyMs?: number;
  request?: "incoming" | "outgoing" | null;
}

interface Role extends Meta {
  hubId?: ID | null;              // null → global/system role
  name: string;
  grants: Record<PermissionKey, boolean>;
  template?: "coven" | "lodge" | "study-group" | "scholarly";
}
type PermissionKey = string;      // 30+ granular, grouped by domain; enforced SERVER-SIDE
```

---

## 7 · Bundles (MBF), sandbox, lineage, agents, inheritance, wellbeing, health

```ts
interface Bundle extends Meta {
  manifest: MBFManifest;
  tier: "official" | "community" | "unverified";
  signature?: { signer: Hex; sig: Hex; verified: boolean }; // verify client-side
  installCount: number;
  closedTradition: boolean;       // blocks public re-share; shows respect notice
}
interface MBFManifest {
  name: string; version: string; maintainer: string;
  type: "pantheon" | "tradition" | "ritual" | "deck" | "sigil-library";
  traditionTags: string[];
  contents: { entities?: Entity[]; templates?: Template[]; library?: LibraryItem[]; assets?: (SigilAsset|TalismanAsset)[] };
  permissionsRequested: string[]; // shown before activation (extension-style consent)
  license: { spdx?: string; attribution: string };
}

interface SandboxInstance extends Meta {
  bundleId: ID;
  isolated: true;                 // NO vault access, NO network until promoted
  conflicts: { incomingEntityName: string; existingEntityId?: ID }[];
  verdict: { newItems: number; clashes: number; selfSigned: boolean };
}

interface LineageAttestation extends Meta {
  subjectIdentityId: ID;
  claim: string;                  // degree/initiation/teacher/membership
  selfSignature: { sig: Hex };
  counterSignatures: { authorityIdentityId: ID; sig: Hex }[];
  state: "self-declared" | "counter-signed" | "revoked"; // ③ DERIVE from signatures, never set by hand
}

interface Agent extends Meta {
  name: string; model: string;
  status: "enabled" | "dormant" | "disabled";
  capabilities: string[];         // allowlist; user consents to each (extension-style)
  costCapCents?: number;
  usage: { inputTokens: number; outputTokens: number; cacheTokens: number; periodCents: number };
  memoryPath: string;             // editable memory file
  // BYO keys — keys never leave the instance
}

interface InheritanceConfig extends Meta {
  vaultId: ID;
  executors: { label: string; pubKey?: Hex; keyShare?: Hex }[];
  checkInIntervalDays: number;
  lastCheckIn: ISO;
  posthumousReleases: { contentQuery: ContentQuery; releaseTo: Visibility }[];
}
interface MemorialState { triggeredAt: ISO; preservedPermanently: true }

interface WellbeingConfig extends Meta {
  vaultId: ID;
  optIn: boolean;                 // OFF by default
  threshold: "ask-only" | "sustained-shift" | "acute";
  region: "intl" | "us" | "uk" | "gr";
  muteUntil?: ISO | null;
  // detection runs ON-DEVICE and is NEVER logged — honor literally
}

interface HealthReport {           // all live ②/③; nothing static
  overall: "operational" | "degraded" | "down";
  services: { key: string; status: "operational"|"degraded"|"expiring"|"down"; detail?: string; expiresAt?: ISO }[];
}
```

```ts
// shared helpers referenced above
type ContentQuery = { types?: ContentType[]; tags?: string[]; identityIds?: ID[]; visibility?: Visibility[] };
interface CelestialStamp { at: ISO; planetaryHour: PlanetaryName; lunarPhase: string; place?: { lat: number; lng: number; label?: string } }
type PlanetaryName = "Saturn"|"Jupiter"|"Mars"|"Sun"|"Venus"|"Mercury"|"Moon";
type GematriaSystem = "full" | "ordinal" | "reduced";
```

---

## 8 · REST API sketch

Conventions: `GET` list endpoints accept `?filter`, `?group`, `?sort`, `?cursor`, `?limit` and
return `{ data, nextCursor }`. All writes require the acting-as `identityId` (from session/header).
Server enforces ACL + permissions on **every** call — the UI gates are advisory only.

```
# Content
GET    /api/entries?type=&tag=&entity=&tradition=&group=&cursor=     → grouped entry collection
POST   /api/entries                      { type, body, acl, tags, entityRefs, citations }
GET    /api/entries/:id
PATCH  /api/entries/:id
DELETE /api/entries/:id                  (soft)
GET    /api/synchronicities?group=date   → date-bucketed + motif aggregates
POST   /api/synchronicities
GET    /api/divinations  ·  POST /api/divinations        (store seed!)
GET    /api/assets/(sigils|talismans|circles)  ·  POST …

# Entities / library
GET    /api/entities?class=&tradition=&planet=
GET    /api/entities/:id                 → entity + alias edges + unified views + citations
POST   /api/entities/:id/aliases         { toEntityId, relation }
GET    /api/unified-views  ·  POST /api/unified-views
GET    /api/library?category=&lang=

# Identity / account / settings
GET    /api/identities  ·  POST  ·  PATCH /:id  ·  POST /:id/archive  ·  POST /:id/rotate-key
GET    /api/account/memberships  ·  POST /api/account/memberships/:id/leave
GET    /api/account/viewers      ·  POST  ·  DELETE /:id           (private viewer grants)
GET    /api/account/billing      → Stripe-backed; never fabricate amounts
GET/PUT /api/settings            (theme/mode/font/a11y/encryption)

# Computed (server may compute or validate client computation)
GET    /api/celestial?lat=&lng=&at=      → { planetaryHour, lunarPhase, transits[] }
GET    /api/calendar/resolve?tradition=Beltane&year=2027   → { at: ISO, planetaryHour }

# Publishing
GET/POST /api/posts  ·  /api/essays  ·  /api/publications  ·  /api/newsletter/issues
POST   /api/newsletter/issues/:id/send   { audience }            (or schedule)
GET    /api/templates?category=  ·  POST /api/templates
GET    /api/scheduler/releases   ·  POST  ·  POST /:id/release-now  ·  DELETE /:id

# Network
GET    /api/hubs/:id                      (public profile)
POST   /api/hubs/:id/petitions            (join request)
GET    /api/hubs/:id/members?degree=      ·  POST /api/hubs/:id/petitions/:pid/(admit|decline)
GET    /api/hubs/:id/rituals  ·  POST /:rid/rsvp  ·  GET /:rid/ical
GET    /api/federation/peers  ·  POST /api/federation/peers/:id/(accept|reject|block)
GET    /api/federation/mode   ·  PUT /api/federation/mode
GET    /api/sso/request/:token  ·  POST /api/sso/authorize  ·  DELETE /api/sso/grants/:id
GET    /api/roles  ·  PATCH /api/roles/:id  ·  GET /api/permissions/preview?role=

# Advanced
GET    /api/bundles?type=&tier=  ·  GET /api/bundles/:id
POST   /api/bundles/:id/sandbox           → SandboxInstance (isolated)
POST   /api/sandbox/:id/(discard|promote) (promote → conflict resolution → vault)
GET    /api/lineage/attestations  ·  POST  ·  POST /:id/countersign  ·  POST /:id/revoke
POST   /api/lineage/verify                { attestationId }  → client SHOULD also verify locally
GET    /api/agents  ·  PATCH /api/agents/:id  ·  GET /api/agents/:id/usage
GET/PUT /api/inheritance  ·  POST /api/inheritance/check-in
GET/PUT /api/wellbeing                    (detection stays client-side; this stores prefs only)
GET    /api/health                        → HealthReport (live probes)
```

---

## 9 · Shared component inventory (build once, use everywhere)

Props are sketched in TS. Everything is **themeable via tokens** and **a11y-complete** (see onboarding
§7, §9). Names match the onboarding doc.

### Primitives
```ts
Button({ variant: "primary"|"secondary"|"ghost"|"danger"|"quiet", size?: "sm"|"md"|"lg",
         iconStart?: GlyphName, iconEnd?: GlyphName, loading?: boolean, disabled?, onClick })
IconButton({ glyph: GlyphName, label: string /*required for SR*/, … })
Field({ label, hint?, error?, required?, children })          // wraps any input; owns the a11y wiring
TextInput · TextArea · Select · NumberInput                   // all go inside <Field>
Switch({ checked, onChange, label })                          // aria-checked
SegmentedControl<T>({ options: {value:T,label,glyph?}[], value, onChange })
Chip({ label, glyph?, selected?, onToggle?, removable? })
Card({ as?, interactive?, children })                         // the surface primitive
Badge({ tone: "neutral"|"info"|"success"|"warning"|"danger"|"trust", glyph?, children })
Stat({ label, value, spark?: number[], delta? })
Progress({ value, max, label })
Avatar({ identity, size })                                    // photo OR generated glyph medallion
Medallion({ glyph, tone })                                    // entity/identity ring glyph
StatusDot({ status })                                         // paired with text, never color-only
EmptyState({ glyph, title, body, action? })                  // humane voice; every collection needs one
Skeleton({ kind })                                            // loading placeholder per collection
```

### Glyph / icon
```ts
Glyph({ name: GlyphName, size?, title? })   // engraving sprite, currentColor, ~1.4 stroke
// GlyphName covers UI + subject glyphs (planetary/zodiac/element/lunar). Expansion is a known TODO.
```

### Overlays — the no-native-dialog family (addendum hard rule)
```ts
// All focus-trapped, ESC-dismissible, SR-correct, themed. NEVER alert()/confirm()/prompt().
ConfirmDialog({ tone: "destructive"|"constructive"|"neutral", title, body, confirmLabel,
                cancelLabel?, onConfirm, onCancel })
AlertDialog({ title, body, acknowledgeLabel, onAck })          // irrevocable; e.g. encryption warnings
PromptDialog({ title, label, defaultValue?, validate?, onSubmit, onCancel })
Toast.push({ tone: "info"|"success"|"warning"|"error", title, body?, action? })  // non-blocking
Banner({ tone, title, body, dismissible?, action? })           // inline, persistent
Drawer({ side?: "right"|"left", title, children, onClose })
Menu({ trigger, items })                                       // arrow-navigable
Tooltip · Popover
```

### Cross-cutting domain controls
```ts
VisibilitySelector({ value: ACL, onChange })
  // 5 rungs (Personal/Viewer/Network/Public/Sealed); live explanation; Sealed ⇒ encryption.
  // Goes on EVERY composer (entry, post, publication, quick-capture).
SensationDiagram({ points: SensationPoint[], onChange })       // editor /sensation block; click to cycle
IdentityPicker({ value: ID, onChange, scope?: SurfaceKey })    // "acting-as"; write-time author choice
EntityRefPicker({ value: EntityRefTarget, onChange })          // entity OR unified view
LanguageToolbar({ onInsert })                                  // uses transliteration engine
CelestialBand({ lat, lng })                                    // planetary hour + lunar + date; self-updating
CalendarDate({ at: ISO, calendars: ("gregorian"|"hellenic"|"hebrew"|…)[] }) // multi-calendar render
RingText({ radius, text, script? })                            // ⚠ sets textLength=2πr, lengthAdjust="spacing"
QuickCapture({ defaultType?, onSaved })                        // global overlay; same write path as Synchronicity composer
```

### Shell
```ts
AppShell({ nav: <VaultNav/>, topbar, children })   // owns the scroll convention (see onboarding §8)
VaultNav({ active, identity })                      // grouped nav; acting-as switcher
PublicChrome({ children })                          // public-surface header/footer
PrintSheet({ pageSize, children })                  // fixed page, parchment screen preview, real @page print
ModeLayout({ kind: "trance"|"ritual", children })   // full-screen, no app shell; a11y floors still apply
```

---

## 10 · Computed-engine signatures (port the ACCURATE mockups; don't re-derive)

Put these in a shared `engines/` (or `lib/`) and have BOTH the workbench tool and its embed/consumer
call the same function. The mockups noted "(ACCURATE)" contain verified implementations — lift them.

```ts
// ── Celestial (Today, Synchronicity, Ritual Feed, CelestialBand) ──
planetaryHour(at: Date, lat: number, lng: number): { planet: PlanetaryName; index: number; nextChangeAt: Date }
lunarPhase(at: Date): { phase: string; illumination: number /*0..1*/ }
transitsOfNote(at: Date): { body: string; aspect: string; exactAt: Date }[]

// ── Calendar (Scheduler tradition-resolver, multi-calendar display) ──
resolveTraditionDate(name: string, year: number, tz: string): { at: Date; planetaryHour: PlanetaryName }
toCalendar(at: Date, system: "gregorian"|"hellenic"|"hebrew"|"coptic"): string

// ── Gematria (Workshop instrument + editor /gematria) — SAME util both places ──
gematria(input: string, system: GematriaSystem): number

// ── I Ching (Oracle reference; Divination's iching tab calls THIS) ──
ichingCast(seed: string): IChingCast            // 6 coin-casts → King Wen hexagram + changing/becoming
hexagram(n: number): { name: string; trigrams: [string,string]; judgment: string } // verified King Wen table

// ── Geomancy (Oracle reference; Divination's geomancy tab calls THIS) ──
geomancyCast(seed: string): GeomancyCast        // 4 Mothers → Daughters/Nieces/Witnesses/Judge (XOR derivation)
geoFigure(name: string): { rows: GeoFigure["rows"]; verdict: string } // 16 canonical figures + dot patterns

// ── Kamea / sigil (Sigil Studio + Talisman + print sheets) — ONE engine ──
kamea(planet: PlanetaryName): { square: number[][]; magicConstant: number }
traceSigil(intent: string, planet: PlanetaryName): { x: number; y: number }[] // letters → path over square

// ── Transliteration (Transliterate tool + editor LanguageToolbar) — ONE engine ──
transliterate(input: string, target: "el"|"he"|"ar"|"hi"|"cop"):
  string  // digraph-aware (th→θ, sh→ש); Greek final-sigma; RTL handling. A guide, not gospel.
```

**Reproducibility.** Every `*Cast(seed)` is deterministic in `seed`. Persist the seed on the record so
a reading re-renders identically and can be audited ("scientific illuminism"). Never store only the
rendered result.

---

*Build against these contracts; keep the names stable across surfaces. When the mockup and this file
disagree on a field, this file wins for data shape, the mockup wins for layout, and the brief +
Sophia win for intent.*

---

## 11 · Worked examples — two surfaces traced end-to-end

This is the pattern to repeat for **every** surface. Take the mockup, run the four-bucket audit, pull
the types, plan the fetches, design every render state, then wire the interactions. Two examples
follow: **Today** (teaches the derived-data trap) and **Entity Profile** (teaches collection + graph +
dialog-write). Pattern-match the rest against these.

---

### 11.1 · `Theourgia Vault - Today.dc.html` — the derived-data trap

**Step 1 — What the mockup shows.** A celestial top band ("Hour of Mercury · Waxing Gibbous, 87% ·
1 Mounukhiṓn"), a couple of "transits of note", a recent-entries list, and a quick-capture trigger.
Everything has plausible, specific values.

**Step 2 — Four-bucket audit** (onboarding §2). Ask of each element: *"if a different practitioner
logged in, or it were a different day/place, would this change?"*

| Element | Bucket | Why |
|---|---|---|
| Page frame, nav, section headers, "Recent" label | **① chrome** | Same for everyone, every day. |
| "Hour of Mercury", "Waxing Gibbous 87%", "1 Mounukhiṓn", transits | **③ derived** | Pure function of `now` + the user's lat/lng. The single most mis-shipped band in the app. |
| Recent-entries rows | **② feed** | A query: most-recent N entries for the acting identity. |
| Quick-capture (type + visibility, writes) | **④ state** | Real composer → `POST /api/entries`. |

**Step 3 — Types** (from §1, §2, §7). `Entry`, `CelestialStamp`, `PlanetaryName`, `Visibility`/`ACL`.

**Step 4 — Data + compute.**
```ts
// ③ derived — compute live, recompute on a timer. NEVER store the mockup's strings.
const { lat, lng } = await getUserLocation();      // from settings/profile
function refreshCelestial() {
  const now = new Date();
  const hour    = planetaryHour(now, lat, lng);    // §10 engine
  const moon    = lunarPhase(now);
  const date    = toCalendar(now, activeCalendar); // user's calendar pref
  const transits= transitsOfNote(now);
  setCelestial({ hour, moon, date, transits });
}
useEffect(() => {
  refreshCelestial();
  const t = setInterval(refreshCelestial, 60_000); // re-derive as the hour turns
  return () => clearInterval(t);
}, [lat, lng, activeCalendar]);

// ② feed
const recent = useQuery(() =>
  api.get(`/api/entries?identityIds=${actingId}&sort=-createdAt&limit=8`));
```

**Step 5 — Every render state** (not just the happy path the mockup shows):
- **Loading:** `<CelestialBand>` shows a skeleton until the first compute resolves (geolocation can be
  async / denied); recent list shows `<Skeleton kind="entry-row"/>` ×8.
- **No location permission:** band degrades gracefully — show date + lunar (location-independent),
  and a quiet `<Banner tone="info">` offering to set a location for planetary hours. Never block.
- **Empty (new vault, zero entries):** `<EmptyState glyph="quill" title="Nothing written yet"
  body="Your first entry begins the record." action={<Button>Open the editor</Button>}/>` — humane
  voice, not a barren list.
- **Error:** recent-list fetch fails → inline `<Banner tone="error">` with a retry, band still shows.
- **Loaded:** the mockup.

**Step 6 — Interactions.** Quick-capture → `<QuickCapture>` (the shared overlay, same write path as the
Synchronicity composer). On save: `POST /api/entries` with `{ type, body, acl }`; the server stamps
`capturedContext` (③, computed at save); optimistic-prepend to the recent list; `Toast.push({tone:
"success"})`. Visibility uses `<VisibilitySelector>` — if the user picks **Sealed**, the body is
encrypted before it leaves the browser.

**Step 7 — The trap.** Literal translation ships `Hour of Mercury` as text. It will be wrong within
the hour, wrong for every other user, and wrong in every timezone. The band is **③**, full stop. This
is the canonical example the whole onboarding is built around.

**Step 8 — Component tree.**
```
<AppShell nav={<VaultNav active="today"/>}>
  <CelestialBand lat lng calendar/>            {/* ③ self-updating */}
  <section> Transits of note → derived list </section>
  <QuickCapture defaultType="journal" onSaved={prepend}/>   {/* ④ */}
  <section>
    <h2>Recent</h2>
    {loading ? <Skeleton.../> : recent.length ? recent.map(<EntryRow/>) : <EmptyState.../>}
  </section>
</AppShell>
```

---

### 11.2 · `Theourgia Entity Profile.dc.html` — collection + graph + dialog-write

**Step 1 — What the mockup shows.** One entity (say Hekate): correspondences, an alias graph
(node-edge), a unified-views panel, library citations, and an "add alias" affordance. The graph nodes
and edges look hand-placed; the citations look like a static list.

**Step 2 — Four-bucket audit.**

| Element | Bucket | Why |
|---|---|---|
| Layout, panel headers, "Correspondences"/"Aliases" labels | **① chrome** | Structural. |
| The entity record, its correspondences, the alias edges, unified views it belongs to, citations | **② feed** | All queried for *this* entity id. |
| Graph node **positions** | **③ derived** | A layout computed from the edges — never hand-placed coordinates. |
| Medallion glyph | **③ derived** | From the entity's class/correspondences. |
| "Add alias" dialog, unified-view editor, import-alias prompt | **④ state** | Each writes a typed edge / union. |

**Step 3 — Types** (§4). `Entity`, `Correspondence`, `AliasEdge` (note the four `relation` values —
they're meaningful), `UnifiedView`, `LibraryItem`, plus `EntityRefTarget` for how other surfaces point
here.

**Step 4 — Data.**
```ts
// One detail call returns the entity + its graph neighborhood + memberships + citations:
const data = useQuery(() => api.get(`/api/entities/${id}`));
// → { entity: Entity, aliases: AliasEdge[], unifiedViews: UnifiedView[], citations: LibraryItem[] }

// ③ graph layout is computed from the edges, not stored:
const layout = useMemo(() => forceLayout(data.entity, data.aliases), [data]);
```

**Step 5 — Every render state.**
- **Loading:** medallion + panels as skeletons; graph area shows a quiet placeholder.
- **Empty variants:** no aliases yet → the graph panel shows `<EmptyState glyph="link" title="No
  aliases recorded" body="Relate this entity to others as your understanding deepens."/>`; no
  citations → a one-line quiet empty. A node with no correspondences still renders cleanly.
- **Error:** detail fetch fails → full-panel `<Banner tone="error">` + retry.
- **Loaded:** the mockup.

**Step 6 — Interactions (the writes — all themed dialogs, never native).**
- **Add alias:** `<Button>` → a `PromptDialog`-style picker (`<EntityRefPicker>` for the target +
  `<SegmentedControl>` for `relation`: same-as / aspect-of / syncretic-with / epithet-of) →
  `POST /api/entities/:id/aliases { toEntityId, relation }` → edge appears, graph re-lays-out.
- **Unified view:** drag-select member entities → `POST /api/unified-views { label, memberEntityIds }`.
  Now `<EntityRefPicker>` elsewhere can target this union.
- **Import-alias prompt (shared with Bundle Install):** when an import would collide with an existing
  entity, a `ConfirmDialog tone="neutral"` asks **relate vs. keep distinct** — **default distinct**.
  Choosing relate writes a `same-as` edge; distinct creates a separate entity. Same component both
  places — do not fork it.

**Step 7 — The trap.** Two failure modes here. (a) Hard-coding graph node `x/y` from the mockup — they
must come from `forceLayout(edges)` so the graph stays correct as edges are added. (b) Treating alias
edges as decorative — the four `relation` types carry real meaning (a `same-as` is not an
`aspect-of`), they drive the `<entityRef>`/unified-view resolution, and they're written by real
dialogs. Model the edge type exactly.

**Step 8 — Component tree.**
```
<AppShell nav={<VaultNav active="entities"/>}>
  <header> <Medallion glyph={derivedGlyph}/> {entity.name} {entity.tradition.map(<Badge/>)} </header>
  <Panel title="Correspondences"> {entity.correspondences.map(<Chip/>)} </Panel>
  <Panel title="Aliases" action={<Button onClick={openAddAlias}>Add</Button>}>
    {aliases.length ? <AliasGraph layout={layout}/> : <EmptyState.../>}   {/* ③ layout */}
  </Panel>
  <Panel title="Unified views"> {unifiedViews.map(<UnifiedViewRow/>)} <Button>New union</Button> </Panel>
  <Panel title="Cited in the library"> {citations.length ? citations.map(<LibraryRow/>) : <quiet empty/>} </Panel>

  {addAliasOpen && <AddAliasDialog onConfirm={postAlias} onCancel={…}/>}   {/* ④ themed, focus-trapped */}
</AppShell>
```

---

**The recipe, distilled.** For any surface: (1) screenshot the intent; (2) tag every element ①/②/③/④
with the "different user / different day" test; (3) pull the types from §1–7; (4) write the fetch/
compute; (5) design loading + empty + error + loaded — the mockup only ever shows *loaded*; (6) wire
each ④ write through a shared themed component and the matching API call; (7) re-read the surface's
**Gotcha** in the onboarding doc before you call it done.
