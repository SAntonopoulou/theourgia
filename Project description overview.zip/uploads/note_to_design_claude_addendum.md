# Theourgia — Design Brief Addendum

Hello again, design Claude.

This is a supplementary brief covering everything added to Theourgia's scope since the original [note_to_design_claude.md](note_to_design_claude.md) handoff. Read the original brief first for the foundational design direction (visual language, typography, color, iconography, voice). This addendum focuses on the **new surfaces, constraints, and interaction patterns** that have emerged during scope expansion.

---

## Cross-cutting design constraints (hard rules)

### No native browser dialogs anywhere
**`window.alert()`, `window.confirm()`, `window.prompt()` are prohibited.** All confirmations, alerts, prompts, errors, and notifications must use custom modal / toast / banner components from the design system. This is a hard rule, enforced by ESLint.

Design implications:
- A **ConfirmDialog** component family (Destructive / Constructive / Neutral variants)
- An **AlertDialog** for irrevocable consequences (e.g., "this will permanently delete X")
- A **PromptDialog** for input requests
- A **Toast** component family (info / success / warning / error)
- A **Banner** component for persistent contextual messages
- A **Drawer** component for slide-in panels
- All must be themed (light / dark / high-contrast), focus-trapped, ESC-dismissible, keyboard-navigable, screen-reader-correct

### Premium feel everywhere
The product respects the seriousness of the practice. No SaaS-cheery UI patterns. No emoji-heavy decoration. No spinner-as-feature. Confident, quiet, exact. Tufte-aware visualizations. Editorial typography.

---

## New surfaces to design

### 1. Admin permissions panel (Phase 12)

Hub admins configure user levels and permissions for their network. Required surfaces:

- **Role table** — list of role definitions (admin, officer, moderator, member, observer, custom roles)
- **Per-role permission matrix** — exhaustive checkbox grid of granular permissions (edit content, moderate, manage members, send newsletters, accept federation peers, view audit log, etc.). Likely 30+ permissions; design for clarity (group by domain, search/filter).
- **"Preview as role X" toggle** — admin can experience the hub as if they held only this role's permissions, to verify config
- **Permission-denied feedback** — when a user attempts an action they can't, a clear, non-punitive modal explaining what's needed and the escalation path
- **Permission templates** — pre-built role bundles (coven, lodge, study group, scholarly working group) selectable as starting points

### 2. Magickal Bundle Format (MBF) — import / share UI (Phase 14)

This is a major new feature area for sharing entire magickal systems between practitioners. Design surfaces:

- **Bundle browser** — searchable, filterable by type (pantheon / tradition / ritual / deck / sigil library / etc.), tier (Official / Community / Unverified), tradition tags
- **Bundle detail page** — manifest summary, contents preview, signature verification status, license, provenance chain, install count, last updated, maintainer
- **Bundle install flow** — multi-step:
  1. Preview contents
  2. Review attribution and license
  3. Choose import mode: **sandbox-first** (recommended) or direct-to-vault
  4. Choose piecemeal: import whole bundle or select specific items (pull only one ritual from a tradition bundle)
  5. Resolve conflicts (alias prompts for entity name collisions; see §3 below)
  6. Confirm
- **Sandbox view** — visually distinct from main vault; clear "this is sandbox content" affordance; "promote to main vault" / "discard sandbox" actions
- **Bundle update notification** — diff preview of what changes when updating; "what may break in my content" warnings; one-click apply with rollback option
- **Closed-tradition flag display** — when present, prominent respect-source notice; default-blocks public-share UI affordances

### 3. Entity alias-graph UI (Phase 5)

A new architectural element with subtle but critical UX. Surfaces:

- **Entity profile page** with new sections:
  - **Aliases panel** — visualizes the alias graph (this entity's relationships to others). Read-only graph showing typed edges (same-as / aspect-of / syncretic-with / epithet-of) connecting to other entity cards.
  - **"Add alias" action** — dialog to relate this entity to another, picker for relationship type
- **Unified views editor** — manage saved unions (e.g., `Hekate-all` = union of three entity_ids). Drag-and-drop selection of which entities to include.
- **`<entity-ref>` block in editor** — dropdown picker offers:
  - "Specific entity: Hekate-PGM"
  - "Unified view: Hekate-all"
  - Visual indicator of which kind is chosen at write time
- **Import alias prompt** — when importing a bundle that adds same-named entities, modal asks: "You're importing 'Hekate' from [Bundle X]. You already have entities named 'Hekate'. How are they related?" with options + a default of `distinct`.

### 4. Multi-identity selector (Phases 4, 5, 10)

Magicians have multiple author identities. Required affordances:

- **Identity switcher** in the top nav (next to user avatar) — small dropdown showing active identity; switch by clicking
- **Identity picker** at write time — when creating an entry / post / publication, choose which identity authors it. Default per-entry-kind configurable in settings.
- **Identity management page** in settings — add / edit / archive identities; default-identity-per-surface picker; each identity has its own avatar, display name, bio, signing keypair
- **Public profile per-identity** — when a visitor views a magician's public face, they see the chosen public identity for that surface (vault homepage shows one identity, blog might show another)

### 5. Lineage attestation display + verification (Phase 5)

A new public-facing UI for trust webs. Surfaces:

- **Profile lineage section** — displays declared attestations (initiations received, teachers, granted degrees, order memberships)
- **Per-attestation card** — shows the claim, the magician's signature on it, and any counter-signatures from authorities
- **Verification visual indicator** — clearly distinguishes:
  - Self-declared, unsigned
  - Self-declared, counter-signed by [authority]
  - Revoked
- **"Verify signature" affordance** — anyone viewing can click and the platform fetches the authority's public key and validates the signature in-browser
- **Authority profile** — links to the lodge master / teacher / etc. who counter-signed; they have their own profile with their own attestations

### 6. Blog platform (Phase 4, 10)

A distinct surface from the magickal journal. Surfaces:

- **Blog homepage** per vault — chronological post stream, with filtering by post type (article / photo / link / quote / video)
- **Per-post pages** — clean reading layout, comment thread (if enabled), share affordances
- **Blog admin** — composer (Tiptap-based, same as entries but with blog-specific blocks: featured image, excerpt, tags, scheduled date)
- **"Publish or schedule" picker** in composer — option for "publish now" / "schedule for [date]" / "save as draft"
- **Scheduled posts queue** — admin view of upcoming releases with edit / cancel
- **Multi-author display** when multiple identities have posted to the same blog

### 7. Time-released content scheduler (Phases 4, 10)

For curricula, posthumous publication, scheduled releases. Surfaces:

- **"What's queued" admin view** — chronological list of all scheduled releases (entries, posts, publications, newsletter issues) with edit / cancel / "release now" actions
- **Scheduler picker** in any content composer — date / time picker with timezone awareness; tradition calendar overlay so the magician can pick "Beltane 2027" rather than calculate
- **Curriculum unlock view** for subscribers — visual progress through a multi-part series with unlock dates visible

### 8. Digital inheritance / memorial mode (Phase 15)

End-of-life provisions for the magician's vault. Subtle, tone-conscious design needed.

- **Executor setup wizard** — guided flow to designate a digital executor; explains the encryption-key-share mechanism gently; emphasizes "have this conversation with your designated person"
- **Check-in mechanic configuration** — picker for "if I don't log in for N months, notify [person]"
- **Memorial mode trigger interface** — for the executor when the trigger fires
- **Memorial-mode vault view** — distinct from active vault; in-memoriam framing ("This vault is in memoriam for [identity]"); only public content visible; preserved permanently; no active interactions
- **Posthumous publication management** — author can mark entries for posthumous release; preview of what would be published when

### 9. AI agent integration surfaces (Phase 16)

For magicians who opt in to the AI agent layer. Multiple surfaces:

- **Agents admin page** — list of installed per-purpose agents (divination companion, scrying partner, ritual aide, study tutor, correspondence helper, synchronicity reviewer) with status (active / dormant / disabled), token usage, cost cap
- **Per-agent configuration** — capabilities (capability allowlist), memory directory (link to view/edit memory files), model selection (Opus / Sonnet / Haiku), cost cap, system prompt review
- **Capability consent UI** at install time — browser-extension-style permission grant; user sees every capability the agent will use before activating; granular accept/decline
- **Token usage dashboard** — per-agent input/output/cache tokens; daily / weekly / monthly totals; cost; fresh-vs-resume breakdown
- **Per-agent activity log** — human-readable narration ("The divination companion read 3 past Hekate readings and noted 2 recurring symbols")
- **"Wake agent" affordance** — context-sensitive (e.g., on a tarot reading session page, a small "ask the divination companion" button)
- **Cost cap warning** — non-blocking toast when approaching cap; modal at cap
- **BYO-keys configuration** — Anthropic API key OR Claude subscription auth; clear "your keys never leave your instance" framing

### 10. SSO across networks (Phase 12)

For one-identity-across-networks workflows. Surfaces:

- **Hub join flow** — "Sign in with Theourgia" button on public hubs accepting SSO; redirects to home vault's authorization page; consent screen showing what the hub will see
- **Per-hub access requests dashboard** — for hubs requiring approval, hub admins see pending requests from SSO'd magicians
- **Magician's SSO history** — admin view of which hubs they're SSO'd into, with per-hub revoke option

### 11. Network group ritual feed (Phases 11, 12)

For coordinating shared ritual work. Surfaces:

- **Per-hub upcoming rituals page** — list view + calendar view; each ritual shows time in viewer's timezone + planetary hour at viewer's location
- **Ritual detail page** — script, materials, participants, RSVP button
- **iCal subscription affordance** — "subscribe to this hub's ritual schedule" with copy-link/QR code for one-tap setup in calendar apps
- **Post-ritual collective log** — shared notes from participants merge into one record

### 12. Print-quality book preview (Phase 10)

For book publishing. Surfaces:

- **Book composer** — chapter outline + content composition with print-aware features (drop caps, footnotes, glossary markers, index keys)
- **Print preview** — true print-grade rendering with bleed marks, crop marks; flip-through preview as if reading the bound book
- **Cover designer** — front + spine + back layout; trim-size selection (POD specs supported)
- **Index / glossary autogen preview** — show what the auto-generated index/glossary will look like; let author add/remove entries before publishing

### 13. Crisis-aware nudge (Phase 15, opt-in)

A particularly tone-sensitive UI. Required:

- **Settings toggle** — clearly labeled, opt-in, never on by default
- **The nudge itself** — small dismissible card; never modal; never alarming; tone exactly between "I noticed and care" and "you're capable, here are resources if useful"
- **Regional resource list** — picker for region; community-maintained list of crisis lines and magick-literate therapists
- **Easy mute** — "don't show again" available on first display; user controls mute duration

### 14. Health-check dashboard (Phase 15)

For self-hosters. Admin-only view showing real-time service health: API status, federation peer reachability, backup status, last successful migration, plugin health, agent daemon status (if enabled), Cloudflare token validity, certificate expiration countdown.

---

## Updated questions to resolve with the maintainer

Adding to the original list of design-decisions-pending:

5. **Identity switcher pattern** — top-nav dropdown vs. command-palette-style switcher vs. embedded in user menu?
6. **Bundle browser visual style** — grid of cards vs. list vs. hybrid?
7. **Alias-graph visualization** — node-edge diagram, table form, or progressive disclosure (default table, optional graph view)?
8. **Token usage dashboard chart family** — sparklines per-agent, stacked area for daily totals, or both?
9. **Memorial mode visual indicator** — subtle border treatment? In-page banner? Separate URL theme?
10. **Closed-tradition respect notice format** — how prominent, how persistent? Must communicate "honor the source" without being preachy.
11. **Scheduled-content "what's queued" view** — calendar style or chronological list (or selectable)?
12. **Sandbox visual distinction from main vault** — different theme color? Watermark? Header bar?

---

## What hasn't changed

Everything from the original [note_to_design_claude.md](note_to_design_claude.md) still stands:
- Typography is the heart of the design (multi-script support is non-negotiable)
- Color directions A (antiquarian library) and B (modern editorial) — still both candidates; pick one for the base
- Custom icon set (no Lucide / Heroicons)
- WCAG 2.2 AA accessibility minimum
- Voice and tone: confident, quiet, exact

Build something worthy of the practice. 🕯️
