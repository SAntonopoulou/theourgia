# Theourgia — Build Progress

Living tracker. `[x]` done · `[~]` in progress · `[ ]` not started.
See `CLAUDE.md` for locked decisions and `uploads/note_to_design_claude.md` for the full brief.

> ## ▶ NEXT SESSION — START HERE
> 24 surfaces built & verified (see "File structure" below). To continue, in a NEW chat in THIS
> project say e.g.: *"Read CLAUDE.md and PROGRESS.md, then build the next unbuilt surface — match
> the pattern of `Theourgia Journal.dc.html` (shared `VaultNav`, the `<helmet>` token block, the
> theme/mode switcher, inline styles only)."*
> - **⚠ Circular name-rings (talisman/circle/print):** SVG `<textPath>` MUST carry `textLength`=2πr (the
>   ring radius) + `lengthAdjust="spacing"` so glyphs distribute EVENLY around the full circle. Without
>   it the text flows from the top and stops/overruns at the seam (uneven gap). Fixed across Talisman,
>   Circle, Print Talisman.
> - **The design system is codified**: every surface copies the same `<helmet>` `:root` + `[data-theme]`
>   + `[data-mode]` token block, imports `VaultNav.dc.html`, and uses the same logic-class
>   theme/mode switcher. A new build inherits all of it by copying any existing surface.
> - **⚠ App-shell scroll convention (fixed retroactively across all 18 shells):** the root grid MUST
>   include `grid-template-rows:minmax(0,1fr)` and every internal scroller (`main`, sidebar `aside`,
>   scrolling panes) MUST carry `min-height:0` alongside `overflow-y:auto`. Without these the grid row
>   auto-sizes to content and the root's `overflow:hidden` CLIPS overflow instead of scrolling — looks
>   fine only when content fits the viewport. Document/specimen pages (Foundations, Profile, Blog, SSO,
>   Book Preview) instead use a single `min-height:100vh` wrapper with NO inner overflow — they page-scroll.
> - **Remaining surfaces:** (executor setup wizard · bundle detail page · blog
>   single-post + composer).
> - **Packaged deliverables still to extract:** `tokens.css`/JSON (lift the `:root`/theme blocks from
>   any surface), the written style-guide doc, a consolidated icon SVG sprite.
> - **Hard rules** (in CLAUDE.md): no native dialogs (use the `Theourgia Overlays.dc.html` family);
>   WCAG 2.2 AA; premium/quiet voice; no purple gradients / occult kitsch.

---

## ▶ RESPONSIVE (mobile / tablet / small-desktop) — added this pass

**System** (full spec in `agent_onboarding.md` §9). Breakpoints: **≤640 phone · 641–1024 tablet ·
1025–1366 small-desktop · ≥1367 large**. Desktop layout stays inline (first paint); a shared
`<helmet>` `@media` block overrides at smaller widths via namespaced `om-*` hooks + layout tokens
(`--shell-nav-w`). Below 1024 the sidebar becomes an **off-canvas drawer**: `.om-shell[data-nav-open]`
toggled by a **delegated, framework-agnostic `<script>`** (one per file, guarded by
`window.__omNavWired`) — `.om-menu` hamburger in the `.om-topbar`, `.om-scrim` backdrop, ESC + scrim
to close, `aria-expanded` kept in sync, 44px touch targets, reduced-motion aware. No per-surface logic
edits needed (React never manages `data-nav-open`).

**To extend to a new app-shell surface:** copy the `<style>` responsive block + the `<script>` into
`<helmet>`, add `class="om-shell"` to the root grid div (and `grid-template-columns:var(--shell-nav-w) …`),
add `class="om-topbar"` + the `.om-menu` button to the topbar, drop a `.om-scrim` div after the
VaultNav import. (`Theourgia Vault - Today.dc.html` inlines the same contract via React `navOpen`.)

**Status**
- [x] **App-shell surfaces (31) — drawer + responsive shell, done & verified.** Today + VaultNav
  (reference), Journal, Entities, Library, Divination, Sigil Studio, Talisman, Circle, Oracle,
  Workshop, Analytics, Synchronicities, Transliterate, Templates, Editor, Scheduler, Settings,
  Account, Permissions, Bundles, Bundle Install*, Agents, Health, Federation, Ritual Feed, Membership,
  Newsletter Composer, Sandbox, Identities, Entity Profile, Wellbeing, Interaction Patterns.
- [x] **Public surfaces with collapsing top-nav (7):** Landing, Blog, Hub, Lineage, Book, Profile,
  Newsletter — section-nav hides ≤860px, theme segmented hides ≤600px (logo + mode toggle remain).
- [x] **Docs 3-col** → TOC hides ≤1080px, nav-tree ≤820px (single column).
- [x] **Fixed-px workbench/admin grids stacked:** Circle + Talisman 3-pane (`264px 1fr 288px` →
  `display:block`, container scrolls, panes flow — verified 0px overflow, all panes visible at narrow
  width); Account settings subnav (`200px 1fr` → stacks above content). Sigil/Editor/Divination/Oracle/
  Workshop already reflow via `flex-wrap`/`auto-fit`.
- [x] **Landing content grids** (manifesto aside, 3- & 4-col specimens) stack ≤720px.
- [x] **Print sheets** (Ritual Sheet, Talisman & Sigil): `.sheet` scales to viewport ≤820px on
  screen; `@media print` untouched.
- [x] **Ritual Mode** already fluid (`clamp()` type throughout, ≥44px controls) — no change needed.
- Acceptable as-is: **Book Preview** facing-page spread scrolls horizontally on phone (a book spread
  is inherently wide; the surround scrolls). The remaining single-column public/specimen pages (Essay,
  Foundations, Style Guide, SSO, Overlays, Memorial, Trance) use `auto-fit` grids that already reflow.

---

## File structure (current)
```
CLAUDE.md                     project memory (auto-loaded)
PROGRESS.md                   this file
uploads/note_to_design_claude.md   source brief
Theourgia Landing.dc.html     [done] marketing landing page + token layer + theme switcher
Theourgia Vault — Today.dc.html [done] vault dashboard: app shell, celestial widgets, quick-capture, recent entries
VaultNav.dc.html             [done] shared sidebar nav child DC (active prop) — imported by all admin surfaces
Theourgia Journal.dc.html     [done] journal index: view tabs, filters, grouped entries, facet rail
Theourgia Divination.dc.html  [done] divination workbench: tarot table + interpretation, 5-tool switcher
Theourgia Entities.dc.html    [done] entity index: class filters, glyph-medallion cards, tradition/planet facets
Theourgia Library.dc.html     [done] library catalog: spine-coded rows, category filters, language facets
Theourgia Sigil Studio.dc.html [done] sigil workbench: intent→kamea construction, 3-pane (method/canvas/properties)
Theourgia Analytics.dc.html   [done] analytics: sparkline stat cards, line chart, practice heatmap, saved studies
Theourgia Editor.dc.html      [done] tiptap editor: drop-cap prose, ritual-log/quote/gematria/sensation blocks, slash menu
Theourgia Trance Mode.dc.html [done] trance/scrying: low-blue-light, breathing timer, dim vision field
Theourgia Ritual Mode.dc.html [done] ritual: full-screen hands-free script, huge Hebrew + translit, big step controls
Theourgia Print — Ritual Sheet.dc.html [done] print preview: parchment ritual sheet, pentagram diagram, @media print
Theourgia Settings.dc.html    [done] settings: theme cards, mode, font roles, a11y switches, per-type encryption + warning
Theourgia Overlays.dc.html    [done] overlay family gallery: toast/banner/confirm/alert/prompt/drawer/command palette/quick-capture
Theourgia Permissions.dc.html [done] admin permissions: role rail + per-role grouped permission matrix, preview-as-role, templates
Theourgia Bundles.dc.html     [done] MBF bundle browser: card grid, type filters, tier badges, signature status, closed-tradition notice
Theourgia Bundle Install.dc.html [done] MBF install wizard: 6-step (preview→license→sandbox/direct→items→alias conflict→confirm)
Theourgia Agents.dc.html      [done] AI agents: agent list (status/cost/model), capability allowlist, token-usage dashboard, activity log
Theourgia Entity Profile.dc.html [done] entity profile + alias-graph (node-edge, typed edges), unified-views panel, correspondences
Theourgia Blog.dc.html        [done] public blog: editorial homepage, featured essay, post-type stream (essay/note/quote/link), subscribe
Theourgia Lineage.dc.html     [done] lineage attestation: trust web, verified/self-declared/revoked states, signature verification
Theourgia Memorial.dc.html    [done] memorial mode: quiet desaturated treatment, candle, preserved writings, remembrances
Theourgia Health.dc.html      [done] self-host health dashboard: overall status, service grid (operational/degraded/expiring)
Theourgia Identities.dc.html  [done] multi-identity selector: top-nav acting-as switcher, identity cards (5, incl. archived), defaults-by-surface, write-time picker demo, detail/edit rail + keypair, themed archive confirm
Theourgia Profile.dc.html     [done] per-identity public profile: light public chrome, owner preview-as banner (Theo/Frater/null), identity hero, verified-key card + lineage attestations, public writings; unsigned/no-lineage state for the chaos pseudonym (unlinkability)
Theourgia Ritual Feed.dc.html [done] network ritual feed (Ordo Theurgica hub): list/calendar views, detail-rich next ritual (order of service, materials, timezone + planetary hour, RSVP going/maybe/can't), upcoming list w/ per-ritual RSVP, post-ritual collective log, iCal-subscribe rail w/ QR. VaultNav gained a Network section (feed/hubs).
Theourgia SSO.dc.html         [done] SSO across networks: secure-authorization consent screen (which identity you present to a hub → live scopes "will see" / "never shared", Sophia-private caution), optional permission toggles, connected-networks rail (SSO history + pending access request), themed revoke confirm.
Theourgia Scheduler.dc.html   [done] content scheduler: "what's queued" (feature next-release card + typed releases: post/newsletter/publication), tradition-calendar picker (by-date vs by-tradition → resolves Solstice/Beltane to real date + planetary hour), curriculum timed-unlock, calendar view, themed release-now/cancel confirms.
Theourgia Book Preview.dc.html [done] print-quality book preview: interior facing-page spread (drop cap, footnote, glossary marker, folios, gutter), cover designer (back·spine·front, barcode, unicursal mark), auto index + glossary; trim-size selector, crop/bleed marks toggles, spread nav. Fixed-parchment print surface (matches Print Ritual Sheet).
Theourgia Wellbeing.dc.html   [done] crisis-aware nudge (Settings → Wellbeing): opt-in toggle (off by default), privacy guarantees (read on device / never logged / never modal), sensitivity threshold (ask-only / sustained-shift / acute), regional resources (Intl/US/UK/Greece, real crisis lines + community magick-literate directory), live interactive nudge preview (calm vigil-lamp, never-red), per-display mute (week/month/off). Tone: "a note, if it's welcome."
Theourgia Foundations.dc.html [done] design-system specimen page (document, page-scroll): wordmark lockups, type roles + display scale + per-script faces (Greek/Hebrew/Arabic/Devanagari/Coptic/gematria), live color-token swatches (surfaces/semantic/6 category accents), radii/spacing/elevation, 22-icon engraving set (1.4 stroke), components (buttons/switch/segmented/chips/field) + overlay-family link. Re-skins live across theme×mode.
Theourgia Talisman.dc.html    [done] talisman designer (3-pane workbench): planetary virtue picker (Saturn/Jupiter/Mars), data-driven concentric talisman SVG — name-ring (Hebrew divine name) + kamea magic square + traced Intelligence sigil (obverse), planetary character + Intelligence ring (reverse); properties rail w/ magic constant, the three spirits (Hebrew), election of time, suffumigation. Reuses Sigil Studio's kamea concept.
Theourgia Circle.dc.html      [done] magical circle builder (3-pane workbench): tradition picker (Golden Dawn/Goetic/Hellenic) re-attributes the quarters + names; toggleable layers (names of power, quarters & elements, warding pentagrams, triangle of art); data-driven circle SVG — double boundary, Hebrew/Greek name-ring, quartered axes w/ elemental glyphs, warding pentagrams, central hexagram, external triangle of art; quarters rail + great-names + implements.
Theourgia Hub.dc.html         [done] per-hub public face (Ordo Theurgica): public light chrome, hero w/ unicursal-star watermark + Latin motto + stats, about, public rites (open/visitors), order writings, petition-to-join card, lineage descent web, officers (→ profiles), verified-hub key. Page-scrolled document; cross-links Lineage + Profile.
Theourgia Book.dc.html        [done] book sales page (Theourgia Press): rendered cover (matches Book Preview), format selector (hardcover/paperback/digital → live price+availability), about, contents, reviews, spec sheet, author card, same-press; themed "Look inside" sample sheet → cross-links Book Preview + Profile. Completes write→schedule→print→sell arc.
tokens/                       [done] PORTABLE TOKEN LAYER: theourgia.tokens.css (~70 vars, base+hellenic+thelemic × dark/light, + LIVE a11y layers [data-contrast=high] & [data-cvd=safe]), tailwind.theourgia.preset.js, theourgia-icons.svg (24-icon engraving SPRITE, <symbol>+<use>, currentColor/1.4-stroke), README.md. Verified.
Theourgia Docs.dc.html        [done] documentation site (public, page-scroll, 3-col): sticky nav tree (active item) + article + sticky "on this page" TOC; header w/ search/version/GitHub; self-hosting quick-start content — syntax-highlighted terminal block (copy btn), NOTE/WARNING/TIP admonitions, config table, next-steps cards, prev/next pager. Cross-links Health dashboard.
Theourgia Essay.dc.html       [done] single essay reading page (public, page-scroll): scroll-driven reading-progress bar, editorial long-form — eyebrow/title/deck, byline w/ Signed badge, drop cap, subheads, pull quote, Greek epigraph card, gematria aside, footnotes; author card (→ Profile + Book), prev/next, subscribe footer. The actual reading view behind the Blog index.
Theourgia Newsletter.dc.html  [done] newsletter archive (public, page-scroll): The Theurgist's Almanac — hero w/ subscribe + cadence/reader stats, featured latest issue (№ + topic chips → Essay), year-grouped archive (2026/2025, № + title + blurb + month), RSS/view-in-browser footer. Pairs with Scheduler's newsletter scheduling.
Theourgia Workshop.dc.html    [done] workshop/generators hub (app shell): builder launcher cards (→ Sigil/Talisman/Circle) + 4 INTERACTIVE quick instruments — live gematria calculator (Latin order, full/ordinal/reduced), current planetary hour (computed from Date + coming hours), barbarous-name generator (PGM-style syllable pools, reroll), sortilege oracle (random cast).
Theourgia Synchronicities.dc.html [done] synchronicity log (app shell): quick-capture composer (charge selector, auto time/planetary-hour, place), date-grouped sign stream (glyph, reading, linked working/entity chip, open/confirmed/noted status), recurring-motifs rail w/ counts + bars, cluster note → Analytics. VaultNav Synchronicities now links here.
Theourgia Federation.dc.html  [done] federation peer browser (app shell, self-host admin): this-instance card w/ federation mode toggle (open/invite/off + live note), pending peer request, connected-peers list (status dot+glow, trust badge, software, shared scope, latency, blocked peer), at-a-glance stats, what-you-share rail → SSO. Pairs with Health + SSO.
Theourgia Newsletter Composer.dc.html [done] newsletter composer (app shell, admin): split editor | live email preview — subject + preview text, body toolbar w/ embedded linked-essay block, parchment-rendered email (Almanac masthead), audience selector (all/supporters), send-as-identity (→ Identities). Pairs with Newsletter archive + Scheduler.
Theourgia Templates.dc.html   [done] template browser (app shell): category filters (workings/divination/journal), template gallery cards (glyph, block count, use count, selectable), preview rail w/ block-structure skeleton + Use-this-template (→ Editor). 6 templates: evocation, daily LBRP, tarot, scrying, dream, pathworking.
Theourgia Oracle.dc.html      [done] reader/caster (app shell): I Ching (coin-cast 6 lines → hexagram via VERIFIED King Wen table, changing lines → becoming hexagram; drawn lines + trigram comp + name) + Geomancy (cast 4 Mothers → derived Daughters/Nieces/Witnesses/Judge shield, 16 correct figures w/ dot patterns + verdicts). Both interactive + accurate.
Theourgia Print — Talisman & Sigil.dc.html [done] print consecration sheets (parchment, @media print, Talisman/Sigil toggle): Jupiter talisman sheet (drawn talisman — name-ring, kamea, traced sigil; virtue/metal/day/square/suffumigation table; consecration rite; signature line) + sigil sheet (intent, reduced letters, traced sigil on lunar square, charging+forgetting rite). Matches Print Ritual Sheet.
Theourgia Style Guide.dc.html [done] style guide doc (public, page-scroll): voice DO/DON'T columns, ornament-&-restraint do/don't rule pairs, color/motion/density cards, WCAG 2.2 AA a11y checklist, "lines we never cross". → Foundations.
Theourgia Membership.dc.html  [done] hub membership management (app shell, officers): stats, petitions-to-read (admit/decline), degree-filtered roster (identity glyph, office, degree, standing dot), by-degree breakdown, dues/standing rail. → Hub public page. Pairs with Hub + Ritual Feed.
Theourgia Account.dc.html     [done] account settings (app shell, settings subnav): network memberships (per-hub, which identity presented, active/pending, leave), private viewers (scoped read grants — teacher/executor/circle, revoke), billing (hosted-vault plan via Stripe, supporter payouts, invoices). Satisfies settings-detail (memberships/viewers/Stripe).
Theourgia Sandbox.dc.html     [done] MBF sandbox view (app shell): distinct blue sandbox chrome + hatched isolation background, bundle items list (entities/templates/library, name-clash flags), permissions-requested panel (granted/review/blocked, no network), on-import verdict (new items / clashes / self-signed) → Bundle Install. Discard vs Import-for-real.
Theourgia Transliterate.dc.html [done] romanization/transliteration helper (app shell): LIVE Latin→Greek / Latin→Hebrew transliteration (digraph-aware: th→θ, sh→ש…; Greek final-sigma; RTL for Hebrew), clickable per-script glyph palette (inserts), copy. Satisfies multi-language input + romanization helpers.
Theourgia Interaction Patterns.dc.html [done] interaction patterns demo (app shell): visibility selector (Personal/Chosen viewers/Network/Public/Sealed — colored rungs + live explanation) + sensation diagram (clickable body map, tap-to-cycle cool/warm/light quality, marked-points list). The two unbuilt interaction components made tangible.
```
Planned additions: `tokens.css` (extracted portable token file), `Theourgia Foundations.dc.html`
(type/color/component specimens), per-surface `*.dc.html` files, `icons/` sprite.

---

## 0 · Foundations
- [x] Token layer — colors, font roles, radii, spacing as CSS vars — `tokens/theourgia.tokens.css`
- [x] Extract tokens to portable `tokens.css` / JSON (Tailwind-ready) deliverable — `tokens/theourgia.tokens.css` + `tokens/tailwind.theourgia.preset.js` + `tokens/README.md`
- [x] Theme override blocks: base / hellenic / thelemic — in `tokens/theourgia.tokens.css` + every surface
- [x] Mode blocks: dark / light — in `tokens/theourgia.tokens.css` + every surface
- [x] High-contrast, colorblind-safe (deut/prot/trit), reduced-motion variants — live `[data-contrast=high]` + `[data-cvd=safe]` + `prefers-reduced-motion` in `tokens/theourgia.tokens.css`
- [x] Wordmark (Θ mark + logotype) — in `Theourgia Foundations.dc.html` (mark, lockup, on-accent) + every header
- [x] Custom icon set (engraving style) → SVG sprite + components — `tokens/theourgia-icons.svg` (24 `<symbol>`s, currentColor, 1.4 stroke)
- [x] Foundations specimen page (typography, color, spacing, components) — `Theourgia Foundations.dc.html` (wordmark, type roles + scale + per-script, live color tokens, form/spacing/radii/shadow, engraving icon set, components + overlay link)

## 1 · Public-facing
- [x] theourgia.com landing page (manifesto / scientific-illuminism pitch) — `Theourgia Landing.dc.html`
- [x] Per-vault public blog — `Theourgia Blog.dc.html`
- [x] Documentation site (Astro Starlight, customized) — `Theourgia Docs.dc.html` (3-col docs reader: nav tree, article w/ code blocks + admonitions + config table, on-this-page TOC; self-hosting quick-start content)
- [x] Per-identity public profile — `Theourgia Profile.dc.html`
- [x] Per-hub public face — `Theourgia Hub.dc.html` (order homepage: rites, writings, petition, lineage, officers, verified key)
- [x] Book sales page — `Theourgia Book.dc.html` (cover, format/price selector, contents, reviews, spec, look-inside → Book Preview)
- [x] Newsletter archive — `Theourgia Newsletter.dc.html` (The Theurgist's Almanac: featured issue + year-grouped archive, subscribe)
- [x] RSS-rendered article page — `Theourgia Essay.dc.html` (long-form reading view: progress bar, drop cap, pull quote, Greek epigraph, footnotes, author card)

## 2 · Vault dashboard (admin)
- [x] Home / Today (planetary hour, lunar phase, transits, recent entries, quick capture) — `Theourgia Vault — Today.dc.html`
- [x] Journal index (chronological / tag / entity / tradition / working views) — `Theourgia Journal.dc.html`
- [x] Entity index (gods/spirits/angels/demons/saints/ancestors) — `Theourgia Entities.dc.html`
- [x] Library catalog — `Theourgia Library.dc.html`
- [x] Divination workbench (tarot, I Ching, geomancy, runes, scrying) — `Theourgia Divination.dc.html` (tarot built full; other tools share the cast frame)
- [x] Sigil studio — `Theourgia Sigil Studio.dc.html`
- [x] Analytics dashboard (scientific-illuminism queries + saved studies) — `Theourgia Analytics.dc.html`
- [x] Magical circle builder — `Theourgia Circle.dc.html` (tradition-attributed quarters, toggleable layers, triangle of art)
- [x] Talisman designer — `Theourgia Talisman.dc.html` (planetary kamea talisman, obverse/reverse, name-ring + traced sigil, spirits + election-of-time)
- [x] Workshop (generators) — `Theourgia Workshop.dc.html` (builder launchers + interactive gematria / planetary-hour / barbarous-name / sortilege instruments)
- [x] Synchronicity quick-capture — `Theourgia Synchronicities.dc.html` (composer w/ charge, date-grouped sign stream, recurring-motifs rail, cluster note)
- [x] Settings — `Theourgia Settings.dc.html` (appearance/theme, font roles, a11y, per-type encryption)

## 3 · Authoring (Tiptap editor)
- [x] Block editor shell + slash commands — `Theourgia Editor.dc.html`
- [x] Custom magical blocks (ritual log, quote citation, gematria, sensation diagram) — in Editor (chart/sigil/divination embeds: stubbed in slash menu, full blocks TODO)
- [x] Template browser + drag-and-drop template designer — `Theourgia Templates.dc.html` (browse/filter/select templates, structure preview, use-in-editor; designer = New-template stub)
- [x] Multi-language input + romanization helpers — `Theourgia Transliterate.dc.html` (live Latin→Greek/Hebrew, digraph-aware, per-script palette) + lang toolbar in Editor

## 4 · Specialized modes
- [x] Trance mode (minimal chrome, low blue light, ambient timer, large text) — `Theourgia Trance Mode.dc.html`
- [x] Ritual mode (full-screen script, hands-free progress) — `Theourgia Ritual Mode.dc.html`
- [x] Print preview (ritual sheet, talisman, sigil) — `Theourgia Print — Ritual Sheet.dc.html` + `Theourgia Print — Talisman & Sigil.dc.html` (talisman + sigil consecration sheets) + `Theourgia Book Preview.dc.html`

## 5 · Network / hub
- [x] Hub home · membership mgmt · group ritual scheduler · newsletter composer · federation peer browser — `Theourgia Hub.dc.html` + `Theourgia Membership.dc.html` + `Theourgia Ritual Feed.dc.html` + `Theourgia Newsletter Composer.dc.html` + `Theourgia Federation.dc.html`deration peer browser `Theourgia Federation.dc.html`, **newsletter composer `Theourgia Newsletter Composer.dc.html`** (membership mgmt remains)

## 6 · Reader
- [x] Tarot session · I Ching · geomancy chart · scrying log — tarot in `Theourgia Divination.dc.html`; I Ching + geomancy in `Theourgia Oracle.dc.html` (interactive, accurate); scrying log template in `Theourgia Templates.dc.html`ia Templates

## 7 · Settings detail
- [x] Encryption mode per content type · theme/a11y prefs — in `Theourgia Settings.dc.html`
- [x] network memberships · private viewers · Stripe — `Theourgia Account.dc.html`

## 8b · Addendum surfaces (`uploads/note_to_design_claude_addendum.md`)
- [x] Overlay/dialog family (Confirm/Alert/Prompt, Toast, Banner, Drawer) + command palette + quick-capture — `Theourgia Overlays.dc.html` (satisfies the no-native-dialogs hard rule)
- [x] Admin permissions panel (role table + permission matrix + preview-as-role) — `Theourgia Permissions.dc.html`
- [x] Magickal Bundle Format (MBF): bundle browser, detail, install flow, sandbox view — `Theourgia Bundles.dc.html` + `Theourgia Bundle Install.dc.html` + **`Theourgia Sandbox.dc.html`** (isolated try-before-import)alone detail page + sandbox vault view TODO
- [x] Entity alias-graph UI (profile aliases panel + unified views editor + import-alias prompt) — `Theourgia Entity Profile.dc.html` (import-alias prompt also in Bundle Install step 5)
- [x] Multi-identity selector (top-nav switcher + write-time picker + identity mgmt + per-identity public profile) — `Theourgia Identities.dc.html` (admin) + `Theourgia Profile.dc.html` (public profile, preview-as switcher, verified-key/lineage, unsigned/anonymous state)
- [x] Lineage attestation display + signature verification — `Theourgia Lineage.dc.html`
- [x] Blog platform (homepage, post page, composer, scheduled queue) — `Theourgia Blog.dc.html` (editorial homepage + stream done; single-post page + composer + queue TODO)
- [x] Time-released content scheduler ("what's queued" + tradition-calendar picker) — `Theourgia Scheduler.dc.html` (queue + calendar, tradition-date resolver, curriculum unlock, release/cancel confirms)
- [x] Digital inheritance / memorial mode (executor wizard, memorial vault view) — `Theourgia Memorial.dc.html` (memorial view done; executor setup wizard TODO)
- [x] AI agent surfaces (agents admin, per-agent config, consent allowlist, token dashboard, activity log) — `Theourgia Agents.dc.html` (install/consent modal + memory editor TODO)
- [x] SSO across networks (hub join/consent, access-requests, SSO history) — `Theourgia SSO.dc.html` (consent screen w/ identity-to-present picker + live scopes, connected-networks history + revoke, pending access request)
- [x] Network group ritual feed (upcoming rituals, detail, iCal, collective log) — `Theourgia Ritual Feed.dc.html` (list + calendar, RSVP, timezone/planetary-hour, collective log, iCal subscribe)
- [x] Print-quality book preview (composer, crop/bleed preview, cover designer) — `Theourgia Book Preview.dc.html` (interior spread, cover designer, index/glossary autogen, trim sizes, crop/bleed marks)
- [x] Crisis-aware nudge (opt-in toggle + dismissible card + regional resources) — `Theourgia Wellbeing.dc.html` (off-by-default opt-in, privacy guarantees, sensitivity threshold, regional resource list, live nudge preview, per-display mute)
- [x] Self-host health-check dashboard — `Theourgia Health.dc.html`

## 8 · Interaction patterns
- [x] Quick capture modal · slash commands · command palette (Cmd+K) · inline language switching — quick-capture + command palette in `Theourgia Overlays.dc.html`; slash menu + lang toolbar in `Theourgia Editor.dc.html`; transliteration in `Theourgia Transliterate.dc.html`
- [x] Calendar-layer toggling · visibility selector (Personal/Viewer/Network/Public/Sealed) · sensation diagram — visibility selector + sensation diagram in `Theourgia Interaction Patterns.dc.html`; calendar layers in `Theourgia Ritual Feed.dc.html`

## Deliverables checklist (from brief §"Deliverables")
- [x] 1 Design tokens (JSON/CSS) — `tokens/theourgia.tokens.css` + `tokens/tailwind.theourgia.preset.js`
- [x] 2 Font stack recommendation + rationale — in `tokens/README.md` (Fonts section) + `Theourgia Foundations.dc.html` (Type) + CLAUDE.md
- [x] App shell pattern (sidebar nav + topbar + content/rail) — `VaultNav.dc.html` + every app surface
- [x] 3 Icon set (sprite + components) — `tokens/theourgia-icons.svg` (24 `<symbol>`s) + Foundations icon grid
- [x] 4 Component library mockups — `Theourgia Foundations.dc.html` (buttons/switch/segmented/chips/field) + `Theourgia Overlays.dc.html` (full dialog/toast/banner/drawer family)
- [x] 5 Surface mockups (light + dark) per surface — every surface ships dark+light via the `[data-mode]` toggle in its header
- [x] 6 Editor block library mockups — `Theourgia Editor.dc.html` (drop-cap prose, ritual-log, quote/citation, gematria, sensation blocks, slash menu)
- [x] 7 Print specimens — `Theourgia Print — Ritual Sheet.dc.html` + `Theourgia Print — Talisman & Sigil.dc.html` + `Theourgia Book Preview.dc.html`
- [x] Style guide doc (do/don't, voice, a11y) — `Theourgia Style Guide.dc.html`

---

## Open questions flagged back to Sophia
1. Per-vault customization depth (how much can a magician theme their public face?)
2. "First-light" onboarding that biases defaults by chosen tradition — build it?
3. Confirm wordmark direction once first draft is in front of you.

## Decision log
- 2026-06-20: Followed Theourgia brief over attached Sakura DS. Modern-editorial, dark-first,
  fully token-driven. Cardo lead; per-theme display swaps. Themes: base/hellenic/thelemic.
  Starting build with the landing page as the anchor surface.
- 2026-06-20: Landing page done + verified (fixed var()-transition repaint bug). Built Vault
  Home/Today dashboard reusing the same token helmet + theme switcher. App shell pattern
  (248px sidebar w/ sectioned nav + engraving icons, topbar w/ search+theme controls, content +
  320px right rail) is now the template for all admin surfaces. Quick-capture type+visibility
  are interactive (state-driven). Layout uses flex-wrap + auto-fit so it degrades below 1440.
