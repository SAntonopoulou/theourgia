# Theourgia — Project Memory

> Auto-loaded every session. Durable decisions only. Live status lives in `PROGRESS.md`.

## What this project is
**Theourgia** — a magickal journal CMS + full practitioner's toolkit. Open source (AGPL-3.0),
self-hostable, federated. Professional infrastructure for working magicians of many traditions.
Seriousness of Notion/Obsidian/Linear applied to ritual practice. NOT a "spiritual app."
Source brief: `uploads/note_to_design_claude.md`.

## ⚠ Design-system note
This project has the **Sakura Studios** design system attached, but it is a MISMATCH (soft pink/
feminine). We follow the **Theourgia brief**, not Sakura. Ignore the pink palette entirely.

## Locked design decisions (confirmed with user)
- **Direction:** modern editorial, dark-first, richer-but-disciplined ornament. Antiquarian-library
  gravity, grimoire typographic care. No purple gradients, no occult kitsch, no AI-mystic art.
- **Everything is themeable.** Build on a CSS-variable token layer (Tailwind-portable). Colors,
  **font roles** (display / serif / ui / mono / per-script), radii, spacing — all tokens.
- **Themes ship:** `base` (tradition-neutral) + `hellenic` + `thelemic` skins via `[data-theme]`.
  Demo persona = Greek theurgist / OTO initiate / chaos magician.
- **Modes:** dark (leads) + light, via `[data-mode]`. Plus high-contrast, colorblind-safe,
  reduced-motion to follow.
- **Type stack:** Cardo is the lead text/serif face (broad Latin + polytonic Greek + Hebrew).
  Balanced personality. Per-theme display swaps demonstrate font themeability:
  base→Cardo, hellenic→GFS Didot, thelemic→Cinzel. UI=Inria Sans, mono=JetBrains Mono.
  Per-script: Hebrew→Frank Ruhl Libre, Arabic→Noto Naskh Arabic, Devanagari→Noto Serif
  Devanagari, Coptic→Noto Sans Coptic.
- **Wordmark:** custom. Theta (Θ) mark in a ring + "Theourgia" logotype.
- **Variations:** one resolved direction, done well (not multiple comps).

## Build conventions
- Single streaming Design Component per surface (`Name.dc.html`). Inline styles + `var(--token)`.
  Theme/mode override blocks live in `<helmet><style>` (custom-property defs only — the allowed
  exception). Element styling stays inline.
- Engraving-style custom icons (uniform stroke ~1.4, `currentColor`). No Lucide/Heroicons.
- Accessibility is non-negotiable: WCAG 2.2 AA, visible focus, reduced-motion, 200% zoom, RTL.

## Voice
Confident, quiet, exact. Direct (never "manifest your dreams!"). Latin/Greek phrasing sparingly as
ornament (`Solve et coagula`, `Γνῶθι σαυτόν`). Error copy humane, never blames the user.

## ⚠ Hard rules (from addendum — `uploads/note_to_design_claude_addendum.md`)
- **NO native browser dialogs.** Never use `alert()`/`confirm()`/`prompt()`. All confirmations,
  alerts, prompts, errors, notifications use themed components: ConfirmDialog (destructive/
  constructive/neutral), AlertDialog (irrevocable), PromptDialog, Toast (info/success/warning/
  error), Banner, Drawer. All focus-trapped, ESC-dismissible, keyboard- + SR-correct, themed.
- **Premium feel.** No SaaS-cheery patterns, no emoji decoration, no spinner-as-feature.
- Big new surface areas (see addendum): admin permissions matrix, Magickal Bundle Format (MBF)
  import/share + sandbox, entity alias-graph, multi-identity selector, lineage attestation,
  blog platform, content scheduler, digital-inheritance/memorial mode, AI-agent surfaces, SSO,
  network ritual feed, print book preview, crisis-aware nudge (opt-in, tone-critical),
  self-host health-check dashboard.
