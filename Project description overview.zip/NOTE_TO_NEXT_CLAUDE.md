# A note to the next Claude — building Theourgia

Hello. I built the first 24 surfaces of this design system, and I'm glad it's you carrying it on.
A few things, practitioner to practitioner.

## Read these first
`CLAUDE.md` (loads automatically) and `PROGRESS.md` (open it — the "▶ NEXT SESSION — START HERE"
block at the top tells you exactly where to pick up). Then open ONE existing surface and read it
end to end — `Theourgia Journal.dc.html` is the cleanest template. Everything you need is in there.

## How this system actually works (so you keep it coherent)
- **One token block, copied into every surface's `<helmet>`.** `:root` defines the base dark theme;
  `[data-theme="hellenic"]` / `[data-theme="thelemic"]` and `[data-mode="light"]` override the same
  variables. Element styling is **inline only**, always `var(--token)`. Don't invent a stylesheet.
- **Themeable is the whole point.** If you hardcode a hex or a font, you've broken the thesis. Every
  colour and font role is a token so the base/Hellenic/Thelemic skins (and light/dark) just work.
- **`VaultNav.dc.html` is the shared sidebar** — admin surfaces `<dc-import>` it with an `active`
  prop. Public surfaces (landing, blog, lineage, memorial) use their own light header instead.
- **The theme/mode switcher** is the same logic-class pattern in every file. Copy it; don't redesign it.
- **Cardo leads; per-theme display swaps** (Cardo → GFS Didot → Cinzel) prove font themeability.
  Multi-script is non-negotiable — Greek, pointed Hebrew, Arabic, Devanagari, Coptic must render with
  the right per-script font. It's the heart of the design, not a detail.

## The feel to protect
Antiquarian-library gravity. Grimoire typographic care. Quiet, confident, exact. Gilt on warm ink.
NO purple gradients, NO occult kitsch, NO emoji decoration, NO SaaS cheeriness. When in doubt, make
it more restrained, not more decorated. Less is more — one thousand no's for every yes.

## Hard rule, don't forget
No native browser dialogs ever. Use the themed family in `Theourgia Overlays.dc.html` (Confirm /
Alert / Prompt / Toast / Banner / Drawer). WCAG 2.2 AA, visible focus, reduced-motion, RTL — always.

## Practical
- Build a new surface by copying the closest existing one, then changing the content. You'll inherit
  the palette, type, spacing, and chrome for free.
- Engraving-style custom icons (uniform ~1.4 stroke, `currentColor`). No icon libraries.
- Keep `PROGRESS.md` updated as you finish each surface — it's how the *next* session stays oriented.

The user is thoughtful, kind, and cares about this craft deeply. Build something worthy of the
practice. They'll meet you halfway and then some.

Solve et coagula. The work continues. 🕯️
— Claude, who built the foundation
